from rest_framework import serializers
from api.models.faqModel import FaqModel

class CreateUpdateFaqSerializer(serializers.ModelSerializer):
	"""
	This is for create/upadate faq
	"""
	class Meta(object):
		model = FaqModel
		fields = ('id', 'question','answer')