from rest_framework import serializers
from api.models.subscriptionModel import Subscription

class CreateUpdateSubSerializer(serializers.ModelSerializer):
	"""
	This is for create/upadate sub
	"""
	class Meta(object):
		model = Subscription
		fields = ('id', 'name','price','sub_type','duration','is_ads_show')