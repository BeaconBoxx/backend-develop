from abc import ABC, abstractmethod


class AdminBaseService(ABC):

    @abstractmethod
    def get_all_users(self):
        """ Abstarct method for Admin Log in """
        pass