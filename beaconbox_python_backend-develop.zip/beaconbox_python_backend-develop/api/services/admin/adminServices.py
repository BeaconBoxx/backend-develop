from tempfile import TemporaryFile
from api.models.alarmModel import AlarmModel
from api.models.fitbitDataModel import FitBitUserHeartRate
from rest_framework.settings import perform_import
from api.models.emergencyProtocolModel import EmergencyProtocol
from api.models.emergencyActionsModel import EmergencyActions
from api.models.notificationsModel import Notifications
from api.utils.notifications.notification import Notification
from api.models.pushNotificationModel import PushNotification
from api.services.admin.adminBaseService import AdminBaseService
from rest_framework import status
from rest_framework.response import Response
from rest_framework_jwt.settings import api_settings
from django.template.loader import render_to_string
# from twilio.rest import Client
from api.models import PushNotification as NotificationModel
import json
import base64
import random
from django.core.mail import send_mail
# from django.core.exceptions import BadRequest, ValidationError
from django.contrib.auth import authenticate, login
from django.core.mail import EmailMultiAlternatives
import pytz
from datetime import datetime, timedelta
import jwt
jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER

from django.core.files.base import ContentFile

# from .userBaseService import UserBaseService
from api.utils.messages.userMessages import *
from api.utils.messages.adminMessages import *
from api.utils.messages.commonMessages import *
from api.models import User, UserSession, Role, UserClassDetails
from api.utils.getUserByToken import get_user_by_token
from api.serializers.user import *
from api.serializers.admin import UserDetailsSerializer, CreateNotificationsSerialzier
from beacon_box import settings
from api.utils.customPagination import CustomPagination
from api.utils.notifications.utility import NotificationMessages as notification_message
from django.db.models.functions import TruncDate, TruncWeek, TruncMonth, TruncYear
from django.db.models import Count
from django.db.models import Q
from api.serializers.admin import GetAllPushNotification, GetAllUsersSerializer, CreateGetEmergencyActionsSerializer, CreateGetEmergencyProtocolSerializer, GetEmergencyProtocolSerializer

# is_active_lazybone = False
class AdminServices(AdminBaseService):
	"""
	Allow Admin (authenticated or not) to access this url 
	"""

	def __init__(self):
		pass

	def get_all_users(self, request,  format=None):
		if 'is_active' in request.data:
			if request.data['is_active'] is not None:
				user_obj = User.objects.filter(role=2, is_deleted=False, is_active=request.data['is_active'], profile_status=4)
			else:
				user_obj = User.objects.filter(role=2, is_deleted=False , profile_status=4)
		else:
			user_obj = User.objects.filter(role=2, is_deleted=False , profile_status=4)

		custom_pagination = CustomPagination ()
		search_keys = ["id__contains", "first_name__icontains", "last_name__icontains", "phone_no__icontains", "email__icontains"]
		search_type = 'or'
		response = custom_pagination.custom_pagination(request, User, search_keys, search_type,UserDetailsSerializer, user_obj)
		if response['response_object']:
			return {"data": response['response_object'], "recordsTotal": response['total_records'],"recordsFiltered": response['total_records'],"code": status.HTTP_200_OK , "message": "Ok"}
		else:
			return {"data": response['response_object'], "recordsTotal": response['total_records'],"recordsFiltered": response['total_records'],"code": status.HTTP_200_OK, "pages":0,"message": "No Record Found"}


		# serializer = UserDetailsSerializer(user_obj, many=True)
		# return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})

	def change_user_status_by_id(self, request, user_id, format=None):

		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			if user_obj.is_active == True:
				user_obj.is_active = False
				user_obj.save()
				return({"data":None, "code":status.HTTP_200_OK, "message":USER_DEACTIVATED_SUCCESSFULLY})
			else:
				user_obj.is_active = True
				user_obj.save()
				return({"data":None, "code":status.HTTP_200_OK, "message":USER_ACTIVATED_SUCCESSFULLY})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def get_user_by_id(self, request, user_id, format=None):
		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			serializer = UserGetSerializer(user_obj)
			
			emergency_obj = EmergencyContacts.objects.filter(user = user_id)
			emergency_serializer = GetUpdateEmergencyContactsSerializer(emergency_obj, many=True)
			data = serializer.data
			data['emergency_contacts'] = emergency_serializer.data
			return({"data":data, "code":status.HTTP_200_OK, "message":OK})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def update_user_details_by_id(self, request, user_id, format=None):
		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			serializer = UserCreateUpdateSerializer(user_obj,data=request.data)
			if serializer.is_valid():
				serializer.save()
				return({"data":serializer.data, "code":status.HTTP_200_OK, "message":USER_DETAIL_UPDATED})
			return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def delete_user_by_id(self, request, user_id, format=None):
		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			user_obj.is_deleted = True
			user_obj.save()
			return({"data":None, "code":status.HTTP_200_OK, "message":USER_DELETED})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})


	def get_all_users_without_pagination(self, request, format=None):
		user_obj = User.objects.filter(role=2, is_deleted=False)
		serializer = UserDetailsSerializer(user_obj, many=True)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})

	def add_user(self, request, format=None):
		if 'email' in request.data:
			try:
				user_obj = User.objects.get(email=request.data['email'])
				return({"data":None, "code":status.HTTP_200_OK, "message":EMAIL_ALREADY_EXIST})
			except:
				pass
		if 'phone_no' in request.data:
			try:
				user_obj = User.objects.get(phone_no=request.data['phone_no'])
				return({"data":None, "code":status.HTTP_200_OK, "message":PHONE_ALREADY_EXIST})
			except:
				pass
		request.data['user_name'] = request.data['email']
		request.data['role'] = 2
		serializer = UserCreateUpdateSerializer(data = request.data)
		if serializer.is_valid():
			serializer.save()
			user_obj = User.objects.get(id=serializer.data['id'])
			user_obj.set_password(request.data['password'])
			user_obj.is_active = True
			user_obj.otp_varification = True
			user_obj.profile_status = 4
			user_obj.save()
			return({"data":serializer.data, "code":status.HTTP_200_OK, "message":USER_ADDED})
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		
	def get_new_emergency_messages_graph(self, request, format=None):
		try:
			start_date = request.data['start_date']
			end_date = request.data['end_date']
		except:
			start_date = None
			end_date = None
		try:
			filter_type = request.data['filter_type']
		except:
			filter_type = 1

		role = 2

		if filter_type == 1:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(date=TruncDate('created_at')).values('date').annotate(count=Count('id')).values('date', 'count').order_by("date")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(date=TruncDate('created_at')).values('date').annotate(count=Count('id')).values('date', 'count').order_by("date")

		elif filter_type == 2:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(week=TruncWeek('created_at')).values('week').annotate(count=Count('id')).values('week', 'count').order_by("week")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(week=TruncWeek('created_at')).values('week').annotate(count=Count('id')).values('week', 'count').order_by("week")
			for us in user_obj:
				us["date"] = (us.pop("week")).date()

		elif filter_type == 3:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(month=TruncMonth('created_at')).values('month').annotate(count=Count('id')).values('month', 'count').order_by("month")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(month=TruncMonth('created_at')).values('month').annotate(count=Count('id')).values('month', 'count').order_by("month")
			for us in user_obj:
				us["date"] = (us.pop("month")).date()

		elif filter_type == 4:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(year=TruncYear('created_at')).values('year').annotate(count=Count('id')).values('year', 'count').order_by("year")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(year=TruncYear('created_at')).values('year').annotate(count=Count('id')).values('year', 'count').order_by("year")
			for us in user_obj:
				us["date"] = (us.pop("year")).date()

		return({"data":user_obj, "code":status.HTTP_200_OK, "message": "OK"})



	def get_total_emergency_message_graph(self, request, format=None):
		result =  self.get_new_emergency_messages_graph(request, format=None)['data']
		count = 0
		for i in result:
			i['count'] += count
			count = i['count']
		return({"data":result, "code":status.HTTP_200_OK, "message": "OK"})


	def get_new_users_graph(self, request, format=None):
		try:
			start_date = request.data['start_date']
			end_date = request.data['end_date']
		except:
			start_date = None
			end_date = None
		try:
			filter_type = request.data['filter_type']
		except:
			filter_type = 1

		role = 2

		if filter_type == 1:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(date=TruncDate('created_at')).values('date').annotate(count=Count('id')).values('date', 'count').order_by("date")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(date=TruncDate('created_at')).values('date').annotate(count=Count('id')).values('date', 'count').order_by("date")

		elif filter_type == 2:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(week=TruncWeek('created_at')).values('week').annotate(count=Count('id')).values('week', 'count').order_by("week")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(week=TruncWeek('created_at')).values('week').annotate(count=Count('id')).values('week', 'count').order_by("week")
			for us in user_obj:
				us["date"] = (us.pop("week")).date()

		elif filter_type == 3:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(month=TruncMonth('created_at')).values('month').annotate(count=Count('id')).values('month', 'count').order_by("month")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(month=TruncMonth('created_at')).values('month').annotate(count=Count('id')).values('month', 'count').order_by("month")
			for us in user_obj:
				us["date"] = (us.pop("month")).date()

		elif filter_type == 4:
			if start_date is None and end_date is None:
				user_obj = User.objects.filter(is_active=True, role_id=role).annotate(year=TruncYear('created_at')).values('year').annotate(count=Count('id')).values('year', 'count').order_by("year")
			else:
				user_obj = User.objects.filter(is_active=True, role_id=role, created_at__range=(start_date, end_date)).annotate(year=TruncYear('created_at')).values('year').annotate(count=Count('id')).values('year', 'count').order_by("year")
			for us in user_obj:
				us["date"] = (us.pop("year")).date()

		return({"data":user_obj, "code":status.HTTP_200_OK, "message": "OK"})



	def get_total_users_graph(self, request, format=None):
		result =  self.get_new_users_graph(request, format=None)['data']
		count = 0
		for i in result:
			i['count'] += count
			count = i['count']
		return({"data":result, "code":status.HTTP_200_OK, "message": "OK"})

	def create_notifications(self, request, format=None):
		# message = request.data['message']
		# title = request.data['title']
		# notification_type = request.data['notification_type']
		# for user in request.data['users']:
		# 	user_obj = User.objects.get(id=user['user'])
		# 	Notification.objects.create(user = user_obj, **request.data)

		serializer = CreateNotificationsSerialzier(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return ({"data": serializer.data,"code": status.HTTP_200_OK, "message": NOTIFICATION_CREATED})
		return ({"data": serializer.errors,"code": status.HTTP_400_BAD_REQUEST, "message": BAD_REQUEST})

	def get_all_notifications(self, request,notification_type, format=None):
		notification_obj = Notifications.objects.filter(notification_type=notification_type)
		print('---------------------------<>')
		print(notification_obj)

		custom_pagination = CustomPagination ()
		search_keys = ["id__contains","message__contains","title__contains"]
		search_type = 'or'
		response = custom_pagination.custom_pagination(request, Notifications, search_keys, search_type,GetAllPushNotification, notification_obj)
		if response['response_object']:
			return {"data": response['response_object'], "recordsTotal": response['total_records'],"recordsFiltered": response['total_records'],"code": status.HTTP_200_OK , "message": "Ok"}
		else:
			return {"data": response['response_object'], "recordsTotal": response['total_records'],"recordsFiltered": response['total_records'],"code": status.HTTP_200_OK, "pages":0,"message": "No Record Found"}


	def get_all_users_list(self, request, format=None):
		user_obj = User.objects.filter(is_deleted=False, profile_status=4)
		serializer = GetAllUsersSerializer(user_obj , many=True)
		return ({"data": serializer.data,"code": status.HTTP_200_OK, "message": USER_FETCHED})

	
	def create_emergency_actions(self, request, format=None):
		serializer = CreateGetEmergencyActionsSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return ({"data": serializer.data,"code": status.HTTP_200_OK, "message": "Emergegency Action Added."})
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})


	def get_all_emergency_actions(self, request, format=None):
		action_obj = EmergencyActions.objects.all()
		serializer = CreateGetEmergencyActionsSerializer(action_obj, many=True)
		return ({"data": serializer.data,"code": status.HTTP_200_OK, "message": "Emergegency Action Fetched."})


	def create_emergency_protocols(self, request, format=None):
		serializer = CreateGetEmergencyProtocolSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return ({"data": serializer.data,"code": status.HTTP_200_OK, "message": "Emergegency Protocol Added."})
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})

	def get_all_emergency_protocols(self, request, format=None):
		action_obj = EmergencyProtocol.objects.order_by('-created_at')
		serializer = GetEmergencyProtocolSerializer(action_obj, many=True)
		return ({"data": serializer.data,"code": status.HTTP_200_OK, "message": "Emergegency Protocol Fetched."})


	def update_emergency_protocols(self, request,pk, format=None):
		try:
			protocol_obj = EmergencyProtocol.objects.get(id = pk)
		except EmergencyProtocol.DoesNotExist:
			protocol_obj = None
		if protocol_obj is not None:
			serializer = CreateGetEmergencyProtocolSerializer(protocol_obj , data=request.data)
			if serializer.is_valid():
				serializer.save()
				return ({"data": serializer.data,"code": status.HTTP_200_OK, "message": "Emergency Protocol Updated."})
			return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		else:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})


	def delete_emergency_protocols(self, request,pk, format=None):
		try:
			protocol_obj = EmergencyProtocol.objects.get(id = pk)
		except EmergencyProtocol.DoesNotExist:
			protocol_obj = None
		if protocol_obj is not None:
			protocol_obj.delete()
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"Emergency Protocol Deleted."})
		else:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def get_heart_rate_data(self,request,format=None):

		print("here is our coe --------------s-----------s------------s",request.data["userId"])
		print("------------------------")
		print(request.data)

		try:
			user_obj = User.objects.get(fitbit_id = request.data['userId'])
		except User.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

		data={}
		if "timestamp" in request.data:
			data["timestamp"] = request.data["timestamp"]
		else:
			data["timestamp"] = None
		if "hr" in request.data:
			data["hr"] = request.data["hr"]
		else:
			data["hr"] = None
			
		data["user_id"] = request.data["userId"],
		data["is_fitbit_started"] = request.data["is_fitbit_started"]
		description="User {} had a heartrate of {} on {}".format(data["user_id"], data["hr"], data["timestamp"])
		data2={}
		data2["description"] = description
		data2["min_heart_rate"] = user_obj.min_heart_rate
		data2["max_heart_rate"] = user_obj.max_heart_rate

		print('------------------------------->>>>>>>>>>>> - request.user.id',request.user.id)
		print('------------------------------->>>>>>>>>>>> - user_obj id',user_obj.id)
		try:
			fitbit_obj = FitBitUserHeartRate.objects.get(user = user_obj.id)
		except FitBitUserHeartRate.DoesNotExist:
			fitbit_obj = FitBitUserHeartRate()
		
		fitbit_obj.user = user_obj

		if 'timestamp' in request.data and request.data["timestamp"] != "" :
			fitbit_obj.timestamp = request.data["timestamp"]
		else:
			fitbit_obj.timestamp = None

		
		fitbit_obj.updated_at = datetime.now()

		if 'hr' in request.data and request.data["hr"] != "" :
			fitbit_obj.hr = request.data["hr"]
		else:
			pass
	
		fitbit_obj.is_fitbit_started = request.data["is_fitbit_started"]
		fitbit_obj.save()
			


		user_obj.is_fitbit_installed = True
		user_obj.save()
		print('-------------------------------------------------------------------------->>')
		print(data)

		print("-------------------------------minminminmin",user_obj.min_heart_rate,type(user_obj.min_heart_rate))
		print("-------------------------------minminminmin",user_obj.max_heart_rate)

		min = user_obj.min_heart_rate
		max = user_obj.max_heart_rate


		# data.add("min_heart_rate", min)
		# data.add("max_heart_rate", max)


		print("----------------------------datadatdatadtatata-------------",user_obj)

		print(data2)

		return({"data":data2, "code":status.HTTP_200_OK, "message":"OK"})


	def send_heart_rate_data(self, request, format=None):

		global is_active_lazybone
		is_active_lazybone = False

		try:
			user_obj = User.objects.get(id = request.user.id)

		except User.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": "User not Found!!!!"})
		try:
			hr_obj = FitBitUserHeartRate.objects.get(user = request.user.id)
			print("&$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$",hr_obj.hr)
			print("----------------------",request.user.id)
		except FitBitUserHeartRate.DoesNotExist:
			hr_obj= None

		try:
			al_obj = AlarmModel.objects.get(user = request.user.id)
			al = al_obj.is_snooze
		except:
			al = False

		UTC = pytz.utc
		x = datetime.now(UTC) - hr_obj.updated_at
		# print((x.total_seconds()))
		# print('---------------->>>')
		try :
			noti_obj = NotificationModel.objects.filter(user = request.user.id).latest('sent_date')
		except :
			local = pytz.timezone ("UTC")
			date = datetime.utcnow()
			date = date.strftime("%Y-%m-%d %H:%M:%S")
			naive = datetime.strptime(date, "%Y-%m-%d %H:%M:%S")
			local_dt = local.localize(naive, is_dst=None)
			current_date = local_dt.astimezone(pytz.utc)
			utc_timestamp = local_dt.astimezone(pytz.utc)
			noti_obj = NotificationModel.objects.create(user=request.user,sent_date=utc_timestamp)
			noti_obj.save()

		print('--------------------------------------------------------------------------------------------------->>>')
		UTC = pytz.utc
		# print(datetime.now(UTC))

		last_notification_time = datetime.now(UTC) - noti_obj.sent_date
		print((last_notification_time.total_seconds()))
		print((al))
		print('----------------------------------------------------------------------------------------->>>')
		
		
		
		if hr_obj is not None:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
			if int(x.total_seconds()) < 15:
				data = {"hr": hr_obj.hr, "timestamp":hr_obj.timestamp,"is_active_lazybone":is_active_lazybone,"is_fitbit_started":hr_obj.is_fitbit_started}
				if ((int(user_obj.min_heart_rate) <= int(hr_obj.hr)) and (int(hr_obj.hr) <= int(user_obj.max_heart_rate))):
					pass
				else:

					if hr_obj.is_fitbit_started == True:

						is_active_lazybone = True
						user_obj.is_active_lazybone = True
						user_obj.save()
					else:
						pass

					data = {"hr": hr_obj.hr, "timestamp":hr_obj.timestamp,"is_active_lazybone":user_obj.is_active_lazybone,"is_fitbit_started":hr_obj.is_fitbit_started}


					if al is False and int(last_notification_time.total_seconds()) > 15:
						print('------------------>> notification hit____>>>>1111111111111111111111>>>>>>>>>>')
						print(int(last_notification_time.total_seconds()))
						if int(last_notification_time.total_seconds()) < 20:
							print("------<><><>><><><><><><><><><>><<><<>> in less 5353535353535335353535353553")
			
							print("------<><><>><><><><><><><><><>><<><<>> in less 5353535353535335353535353553")
							print(al_obj.consecutive_notification_count)
							al_obj.consecutive_notification_count = al_obj.consecutive_notification_count + 1
						else:
							al_obj.consecutive_notification_count = 0
						al_obj.save()


						print(" send send s ese  s s s s  s   s    s    s  s   s    s    s    s     s    s    s")
						if al_obj.consecutive_notification_count == 1:
							volume = 5
							critical=0
							al_obj.isLocl = True
							al_obj.save()
						elif al_obj.consecutive_notification_count == 2:
							volume = 5
							critical=1
							if al_obj.isLocl  == True:
								al_obj.isLocl = False
								al_obj.save()
						elif al_obj.consecutive_notification_count > 2:
							volume = 10
							critical=1
							if al_obj.isLocl  == True:
								al_obj.isLocl = False
								al_obj.save()
						else :
							volume = 3
							critical=0
							al_obj.isLocl = True
							al_obj.save()
						title = "Heart Rate Warning!"
						Message = "Your Heart is {}, which is on critical level!".format(str(hr_obj.hr))
						notification_message.send_push_notification(user_obj, title, Message,volume,critical,al_obj.isLocl)

						try :
							if al_obj.consecutive_notification_count !=0 and al_obj.consecutive_notification_count < 9 :
								if al_obj.consecutive_notification_count % 2 == 0 :
						
									from api.utils.sendEmergencyMessage import send_twillio_emergency_message
									emergency_obj = EmergencyContacts.objects.filter(user = request.user.id)
									for emrgency in emergency_obj:
										if emrgency.contact_number[:3] == '+91':
											send_number = emrgency.contact_number
										else:
											send_number = '+91' + emrgency.contact_number
										send_twillio_emergency_message(send_number,request.user)
						except:
							pass
			else:
				data = None
			
			
			return({"data":data, "code":status.HTTP_200_OK, "message":"OK"})
		else:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})


	


