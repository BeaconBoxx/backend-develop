from api.models import Subscription
from api.serializers.subscription import CreateUpdateSubSerializer
from api.utils import CustomPagination
from rest_framework import status
from api.utils.messages.commonMessages import *
from api.models import User

class SubService():
    """
    create and update the sub 
    """

    def __init__(self):
        pass



    def create(self, request, format=None):
        """
        Create New subscription 
        """
        user = User.objects.get(id=request.user.id)
        if user.role.id == 1 :

            sub = self.get_object_by_name (request.data.get('name'))
            if sub:
                error = {"name": "Subscription with this name already exist"}
                return ({"data": error, "code": status.HTTP_400_BAD_REQUEST, "message": BAD_REQUEST})

            else:
                serializer = CreateUpdateSubSerializer (data=request.data)
                if serializer.is_valid ():
                    serializer.save ()

                    return ({"data": serializer.data, "code": status.HTTP_201_CREATED, "message": "Subscription created successfully!"})

                return ({"data": serializer.errors, "code": status.HTTP_400_BAD_REQUEST, "message": BAD_REQUEST})
        else:
            return ({"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": "You Don't Have Permissions"})



    def delete_ad(self, request, pk, format=None):
        """
        Delete Method.
        """
        user = User.objects.get(id=request.user.id)
        if user.role.id == 1 :
            sub = self.get_object (pk)
            if sub:
                if sub.can_delete is True:
                    sub.delete ()
                    return ({"code": status.HTTP_200_OK, "message": "Subscription deleted successfully!"})
                else:
                    return ({"code":status.HTTP_400_BAD_REQUEST, "message":"Subscription cant be deleted "})
            return ({"code": status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})
        else:
            return ({"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": "You Don't Have Permissions"})



    def get_object(self, pk):
        """
        Get object by Id
        """
        try:
            return Subscription.objects.get (id=pk)
        except Subscription.DoesNotExist:
            None

    def get_object_by_name(self, name):
        """
        Get Object by Name and full_name.
        """
        try:
            return Subscription.objects.get(name=name)

        except Subscription.DoesNotExist:
            None

    # def role_pagination_list(self, request, format=None):
    #     """
    #     returns paginated list of all Roles
    #     """
    #     custom_pagination = CustomPagination ()
    #     search_keys = ['name__icontains', 'id__contains']
    #     search_type = 'or'
    #     roles = Role.objects.filter(is_deleted=False)
    #     roles_response = custom_pagination.custom_pagination(request, Role, search_keys, search_type, RoleDetailSerializer, roles)
    #     return {"data": roles_response['response_object'],
    #             "recordsTotal": roles_response['total_records'],
    #             "recordsFiltered": roles_response['total_records'],
    #             "code": status.HTTP_200_OK, "message": OK}

    def update(self, request, pk, format=None):
        """
        Updates subscription
        """

        user = User.objects.get(id=request.user.id)
        if user.role.id == 1 :
            data = request.data
            sub = self.get_object(pk)
            if sub:
                sub_name_list = Subscription.objects.exclude(name=sub.name).values_list("name",flat=True)
                if request.data["name"] in sub_name_list:
                    error = {"name": "Subscription with this name already exist"}
                    return ({"data": error, "code": status.HTTP_400_BAD_REQUEST, "message": BAD_REQUEST})
                else:

                    serializer = CreateUpdateSubSerializer(sub, data=data)
                    if serializer.is_valid ():
                        serializer.save ()
                        return ({"data": serializer.data, "code": status.HTTP_200_OK, "message": "Subscription updated Successfully!"})
                    else:
                        return ({"data": serializer.errors, "code": status.HTTP_400_BAD_REQUEST, "message": BAD_REQUEST})
            else:
                return ({"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})
        else:
            return ({"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": "You Don't Have Permissions"})

    # def role_detail(self, request, pk, format=None):
    #     """
    #     Retrieve a Role
    #     """                 
    #     role = self.get_object(pk)
    #     if role:
    #         serializer = RoleDetailSerializer(role)
    #         return ({"data": serializer.data, "code": status.HTTP_200_OK, "message": OK})
    #     else:
    #         return ({"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})
