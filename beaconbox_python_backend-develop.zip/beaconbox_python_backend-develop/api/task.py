from beacon_box.celery import app
from api.models import *
# from api.serializers.user import *
import requests
import json
from datetime import date, datetime, timedelta
from api.utils.notifications.utility import NotificationMessages as notification_message
import pytz


@app.task
def send_alarm_and_reminder_notification():
    """
    save leads data
    """
    # print(">>>>>>>>>>>>>>>>>> Reminder notification <<<<<<<<<<<<<<<<<<<<<<<")
    # # send_reminder()
    # print(">>>>>>>>>>>>>>>>>> Reminder Done <<<<<<<<<<<<<<<<<<<<<<<")
    print(">>>>>>>>>>>>>>>>>> Alaram notification <<<<<<<gsgsgsgsgsgsgsgsgsgsgsgsgsgsg&&&&&&&&&&&&&&&&&&&&&&&&&&&&&hbhuvuhvuyv<<<<<<<<<<<<<<<<")
    send_alarm()
    print(">>>>>>>>>>>>>>>>>> Reminderdododododododoodo doddoo doododo odoodo odo odoo odo do o Done <<<<<<<<<<<<<<<<<<<<<<<")

# def send_reminder():
#     tz = pytz.timezone ('Asia/Kolkata')
#     current = datetime.now(tz)
#     date = current.strftime ('%Y-%m-%d') 
#     # print(current.strftime ('%m/%d/%y'))
#     reminder_list = RemainderModule.objects.filter(status=False, date=date, created_by__isnull=False)
#     now_time = current.strftime('%H:%M')
#     print(now_time)
#     for reminder in reminder_list:
#         updated_now_time = datetime.strptime(now_time, "%H:%M").time()
#         print(reminder.time)
#         if reminder.time <= updated_now_time:
#             print("yes")
#             print(reminder.created_by)
#             subject = "reminder-notification"
#             notification_type = "reminder-notification"
#             msg = "reminder-notification".format(reminder.title)
#             extra_args = {"reminder":reminder.id}
#             notification_message.send_push_notification(reminder.created_by, subject, msg, notification_type, extra_args)
#             reminder.status = True
#             reminder.save()
    
#     return "success"


def send_alarm():
    tz = pytz.timezone ('Asia/Kolkata')
    current = datetime.now(tz)
    date = current.strftime ('%Y-%m-%d') 
    alarm_list = AlarmModel.objects.filter(is_active=True, is_snooze=True,isLocl = True)
    now_time = current.strftime('%H:%M:%S')
    for alarm in alarm_list:
        print(alarm.id)
        updated_now_time = datetime.strptime(now_time, "%H:%M:%S").time()
        if alarm.is_snooze == True:
            aram_snooze_time = "09/13/2020, {}".format((alarm.last_alarm_time).strftime('%H:%M:%S'))
            update_snooze_time = datetime.strptime(aram_snooze_time, "%m/%d/%Y, %H:%M:%S")
            time_interval = timedelta(seconds=30)

            new_time = update_snooze_time + time_interval
            print(updated_now_time)
            print(new_time.time())

            if new_time.time() <= updated_now_time:
                print(">>>>>>> yes m in if")
                subject = "reminder-notification"
                notification_type = "reminder-notification"
                msg = alarm.alarm_reason
                extra_args = {"alarm":alarm.id}
                notification_message.send_push_notification(alarm.user, subject, msg, notification_type, extra_args)
                alarm.isLocl = False
                # alarm.is_snooze = False
                alarm.snooze_last_time=updated_now_time
                # alarm.is_active=False
                alarm.save()
            

        else:
            print("yes m in false")
            if alarm.last_alarm_time <= updated_now_time:
                print("yes m in else")
                subject = "reminder-notification"
                notification_type = "reminder-notification"
                msg = alarm.alarm_reason
                extra_args = {"alarm":alarm.id}
                notification_message.send_push_notification(alarm.user, subject, msg, notification_type, extra_args)
                # alarm.is_snooze = False
                alarm.snooze_last_time=updated_now_time
                # alarm.is_active=False
                alarm.save()
    return "success"