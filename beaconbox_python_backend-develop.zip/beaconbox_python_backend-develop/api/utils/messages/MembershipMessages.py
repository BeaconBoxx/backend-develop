MEMBERSHIP_PLAN_CREATED = "MemberShip Plan Created Successfully"
MEMBERSHIP_PLAN_UPDATED = "MemberShip Plan Updated Successfully"
MEMBERSHIP_DELETED = "MemberShip Plan Deleted Successfully"