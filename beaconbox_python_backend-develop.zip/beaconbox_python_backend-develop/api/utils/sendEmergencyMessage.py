import random
import pytz
from twilio.rest import Client
from datetime import datetime, timedelta
#18456134780
from api.models import User

from datetime import date
 



def send_twillio_emergency_message(to_contact, from_user, type=None):
		age = ''
		gender = ''
		if from_user.dob:
			age = int(date.today().year) - int(from_user.dob[-4:])
			print(f'age is {age}')

		if from_user.gender:
			gender = 'male' if from_user.gender == '1' else 'female' 

		try:
			# otp = random.randint (1000, 9999)
			if type is None or type == 1:
				print(from_user.emergency_message,'=========from_user.emergency_messagefrom_user.emergency_message')
				# body_msg = from_user.emergency_message +' '+ from_user.first_name
				body_msg = f'{from_user.first_name}, a {age} {gender} may be experiencing an emergency at {from_user.address}, {from_user.address2}, {from_user.city}, {from_user.state}, {from_user.zip_code}. Their Beacon Boxx has been activated and they require a wellness check. Please use lockbox code {from_user.lock_box_code} to access their location. Additional Details: {from_user.location_directions}, {from_user.property_access_code}.'

				# (Username), a (Age) (Gender) may be experiencing an emergency at (Address Line 1), (Address Line 2), (City), (State), (Zip Code). Their Beacon Boxx has been activated and they require a wellness check. Please use lockbox code (Lockbox Code) to access their location. Additional Details: (Location Directions), (Property Access Code).
			else:
				# body_msg = f"{from_user.first_name} has intervented in the alarm process and signaled that everything is OK. Please feel to perform wellness checks or contact the {from_user.first_name} to verify."
				body_msg = f"{from_user.first_name} has intervened and deactivated the alarm. Please feel free to perform a wellness check or contact user directly to verify."
			account_sid = "ACe91aa98e6d1f900dbd49eb869187d1bd"
			auth_token = "376b2cb67c5fe4e01392de42bd2e0e7d"
			# print("{}{}".format(user.country_code, user.phone_no))
			print("its okkkkkkkkkk")
			client = Client(account_sid, auth_token)
			to = to_contact
			# to = "+918146664616"
			message = client.messages.create(
					to=to_contact,
					from_="+18456134780",
					body=body_msg)
			print("-----<><><><><><><><>,all set ")
			tz = pytz.timezone ('Asia/Kolkata')
			current_time = datetime.now (tz)

			# user.otp = otp
			# user.otp_send_time = current_time
			# user.save ()
			return True
		except:
			return False
