from api.models.userModel import User
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.schemas import AutoSchema
from api.utils.notifications.utility import NotificationMessages as notification_message
from rest_framework.compat import coreapi, coreschema, uritemplate

from api.services.admin import adminServices

adminServices = adminServices.AdminServices()

class AdminGetAllUsersView(APIView):

	def get(self, request,user_id, format=None):
		"""
		Get User Profile By ID
		"""
		result = adminServices.get_user_by_id(request,user_id, format=None)
		return Response(result, status=result["code"])


	def post(self, request, format=None):
		"""
		Get All User with pagination
		"""
		result = adminServices.get_all_users(request, format=None)
		return Response(result, status=result["code"])

	def put(self, request,user_id, format=None):
		"""
		Get All User with pagination
		"""
		result = adminServices.update_user_details_by_id(request,user_id, format=None)
		return Response(result, status=result["code"])

	def delete(self, request,user_id, format=None):
		"""
		Get All User with pagination
		"""
		result = adminServices.delete_user_by_id(request,user_id, format=None)
		return Response(result, status=result["code"])


class ChangeUserStatusView(APIView):
	def put(self, request,user_id, format=None):
		"""
		Change User Status By ID
		"""
		result = adminServices.change_user_status_by_id(request,user_id, format=None)
		return Response(result, status=result["code"])

class AdminGetUserWithoutPaginationView(APIView):
	def get(self, request, format=None):
		"""
		Get All Users Without Pagination (Export CSV)
		"""
		result = adminServices.get_all_users_without_pagination(request, format=None)
		return Response(result, status=result["code"])

class AddUserView(APIView):
	def post(self, request, format=None):
		"""
		Add User By Admin
		"""

		result = adminServices.add_user(request, format=None)
		return Response(result, status=result["code"])

class GetTotalUsersGraphView(APIView):

	def post(self, request, format=None):
		"""
		Get Bank Details By PK
		"""

		result = adminServices.get_total_users_graph(request, format=None)
		return Response(result, status=result["code"])

class GetTotalEmegencyMessageGraphView(APIView):

	def post(self, request, format=None):
		"""
		Get Bank Details By PK
		"""

		result = adminServices.get_total_emergency_message_graph(request, format=None)
		return Response(result, status=result["code"])

class AdminNotificationsView(APIView):


	


	def post(self, request, format=None):
		"""
		Create Push Notifications
		"""

		result = adminServices.create_notifications(request, format=None)
		return Response(result, status=result["code"])


class GetAdminNotificationsView(APIView):


	def post(self, request,notification_type, format=None):
		"""
		Create Push Notifications
		"""

		result = adminServices.get_all_notifications(request,notification_type, format=None)
		return Response(result, status=result["code"])

class GetUsersView(APIView):

	def get(self, request, format=None):
		"""
		Create Push Notifications
		"""

		result = adminServices.get_all_users_list(request, format=None)
		return Response(result, status=result["code"])

class EmergencyActionsView(APIView):

	def get(self, request, format=None):
		"""
		Create Push Notifications
		"""

		result = adminServices.get_all_emergency_actions(request, format=None)
		return Response(result, status=result["code"])

	def post(self, request, format=None):
		"""
		Create Push Notifications
		"""

		result = adminServices.create_emergency_actions(request, format=None)
		return Response(result, status=result["code"])

	# def put(self, request, format=None):
	# 	"""
	# 	Create Push Notifications
	# 	"""

	# 	result = adminServices.update_emergency_actions(request, format=None)
	# 	return Response(result, status=result["code"])

	# def delete(self, request, format=None):
	# 	"""
	# 	Create Push Notifications
	# 	"""

	# 	result = adminServices.delete_emergency_actions(request, format=None)
	# 	return Response(result, status=result["code"])

class EmergencyProtocolView(APIView):

	def get(self, request, format=None):
		"""
		Get All Emergency Protocols
		"""

		result = adminServices.get_all_emergency_protocols(request, format=None)
		return Response(result, status=result["code"])

	def post(self, request, format=None):
		"""
		Cteate All Emergency Protocols
		"""

		result = adminServices.create_emergency_protocols(request, format=None)
		return Response(result, status=result["code"])

	def put(self, request,pk, format=None):
		"""
		Update All Emergency Protocols
		"""

		result = adminServices.update_emergency_protocols(request,pk, format=None)
		return Response(result, status=result["code"])

	def delete(self, request,pk, format=None):
		"""
		Delete All Emergency Protocols
		"""

		result = adminServices.delete_emergency_protocols(request,pk, format=None)
		return Response(result, status=result["code"])


class GetHeartRateDataView(APIView):
	permission_classes=(AllowAny,)

	def post(self, request,format=None):
		"""
		get heart rate data
		"""

		result = adminServices.get_heart_rate_data(request,format=None)
		return Response(result, status=result["code"])


class SendHeartRateDataView(APIView):

	def get(self, request, format=None):
		"""
		get heart rate data
		"""

		result = adminServices.send_heart_rate_data(request,format=None)
		return Response(result, status=result["code"])

class TestView(APIView):

	def get(self, request, format=None):
		user_obj = User.objects.all()
		from django.core.paginator import Paginator
		p = request.data['page']
		# print('------------------------------------------>>>')
		p1  = Paginator(user_obj,4)
		q = p1.page(p)
		print(q.object_list)
		# notification_message.send_push_notification(user_obj, "Test Test", "Message")
		return Response({}, status=200)

