from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.schemas import AutoSchema
from rest_framework.compat import coreapi, coreschema
from api.services.cms_service.cmsService import CmsService

cms_service = CmsService()

class CreateUpdateCmsView(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        """
        create cms
        """
        result = cms_service.create_update_cms(request, format=None)
        return Response(result, status=result["code"])

class GetCmsView(APIView):
    permission_classes = (AllowAny,)

    def get(self, request, format=None):
        """
        get all cms
        """
        result = cms_service.get_cms(request, format=None)
        return Response(result, status=result["code"])

class CreateUpdateFaqView(APIView):
    permission_classes = (AllowAny,)
    def post(self, request, format=None):
        """
        create update faq
        """
        result = cms_service.add_update_delete_Faq(request, format=None)
        return Response(result, status=result["code"])

class GetFaqView(APIView):
    permission_classes = (AllowAny,)
    def get(self, request, format=None):
        """
        get faq view
        """
        result = cms_service.get_faq(request, format=None)
        return Response(result, status=result["code"])

