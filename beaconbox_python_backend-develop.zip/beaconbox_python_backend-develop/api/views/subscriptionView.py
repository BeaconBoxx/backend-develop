from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.schemas import AutoSchema
from rest_framework.compat import coreapi, coreschema
from api.services.subscription import SubService

subService = SubService()




class CreateSubView(APIView):
    # permission_classes = (AllowAny,)
    def post(self, request, format=None):
        """
        create the subscription 
        """
        result = subService.create(request, format=None)
        return Response(result, status=result["code"])


class UpdateSubView(APIView):
    # permission_classes = (AllowAny,)
   
    def put(self, request,pk, format=None):
        """
        update sub.
        """
        result = subService.update(request,pk, format=None)
        return Response(result, status=result["code"]) #

class DeleteSubView(APIView):
    # permission_classes = (AllowAny,)
   
    def delete(self, request,pk, format=None):
        """
        update sub.
        """
        result = subService.delete_ad(request,pk, format=None)
        return Response(result, status=result["code"]) #DeleteSubView

# class RoleDeleteView(APIView):

#     def delete(self, request, pk, format=None):
#         """
#         Delete Existing Role.
#         """
#         result = roleService.delete(request, pk, format=None)
#         return Response(result, status=result["code"])


# class RoleUpdateView(APIView):

#     schema = role_schema

#     def put(self, request, pk, format=None):
#         """
#         Update Existing Role
#         """
#         result = roleService.update(request, pk, format=None)
#         return Response(result, status=result["code"])


# class RoleListWithPaginationView(APIView):

#     def post(self, request, format=None):
#         """
#         Roles with Pagination
#         """
#         result = roleService.role_pagination_list(request, format=None)
#         return Response(result, status=result["code"])


# class RoleDetailView(APIView):

#     def get(self, request, pk, format=None):
#         """
#         Retrieve a Role
#         """
#         result = roleService.role_detail(request,pk)
#         return Response (result, status=result["code"])