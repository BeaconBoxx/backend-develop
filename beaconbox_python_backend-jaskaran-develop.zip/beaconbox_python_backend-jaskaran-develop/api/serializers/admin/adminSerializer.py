from django.db.models import fields
from rest_framework import serializers
from api.models import (User, Branch, Classes, ClassSection, UserClassDetails, UserSectionDetails)

from django.core.exceptions import ValidationError
from beacon_box.settings import TIME12HRSFORMAT, DATEFORMAT
from api.serializers.uploadMedia import UploadMediaDetailsSerializer

class UserDetailsSerializer(serializers.ModelSerializer):
	"""
	Return the details of Login User.
	"""
	full_name = serializers.SerializerMethodField()
	image = UploadMediaDetailsSerializer()
	heart_rate = serializers.SerializerMethodField()
	spo2 = serializers.SerializerMethodField()
	heart_rate_variability = serializers.SerializerMethodField()

	class Meta(object):
		model = User
		fields = (
		'id', 'email', 'first_name', 'last_name', 'phone_no','dob', 'is_active',"image","heart_rate","spo2","heart_rate_variability")

	def get_full_name(self, obj):
		return obj.first_name + ' ' + obj.last_name

	def get_spo2(self, obj):
		return 72

	def get_heart_rate(self, obj):
		return 95

	def get_heart_rate_variability(self, obj):
		return 45

