from .roleSerializer import RoleSerializer, RoleDetailSerializer
