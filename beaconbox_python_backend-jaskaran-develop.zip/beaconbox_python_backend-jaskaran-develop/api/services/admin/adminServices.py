from api.services.admin.adminBaseService import AdminBaseService
from rest_framework import status
from rest_framework.response import Response
from rest_framework_jwt.settings import api_settings
from django.template.loader import render_to_string
# from twilio.rest import Client
import json
import base64
import random
from django.core.mail import send_mail
# from django.core.exceptions import BadRequest, ValidationError
from django.contrib.auth import authenticate, login
from django.core.mail import EmailMultiAlternatives
import pytz
from datetime import datetime, timedelta
import jwt
jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER

from django.core.files.base import ContentFile

# from .userBaseService import UserBaseService
from api.utils.messages.userMessages import *
from api.utils.messages.adminMessages import *
from api.utils.messages.commonMessages import *
from api.models import User, UserSession, Role, UserClassDetails
from api.utils.getUserByToken import get_user_by_token
from api.serializers.user import *
from api.serializers.admin import UserDetailsSerializer
from beacon_box import settings

class AdminServices(AdminBaseService):
	"""
	Allow Admin (authenticated or not) to access this url 
	"""

	def __init__(self):
		pass

	def get_all_users(self, request, role, format=None):
		if 'is_active' in request.data:
			if request.data['is_active'] is not None:
				user_obj = User.objects.filter(role=2, is_deleted=False, is_active=request.data['is_active'])
			else:
				user_obj = User.objects.filter(role=2, is_deleted=False)
		else:
			user_obj = User.objects.filter(role=2, is_deleted=False)
		serializer = UserDetailsSerializer(user_obj, many=True)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})

	def change_user_status_by_id(self, request, user_id, format=None):
		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			if user_obj.is_active == True:
				user_obj.is_active = False
				user_obj.save()
				return({"data":None, "code":status.HTTP_200_OK, "message":USER_DEACTIVATED_SUCCESSFULLY})
			else:
				user_obj.is_active = True
				user_obj.save()
				return({"data":None, "code":status.HTTP_200_OK, "message":USER_ACTIVATED_SUCCESSFULLY})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def get_user_by_id(self, request, user_id, format=None):
		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			serializer = UserGetSerializer(user_obj)
			return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def update_user_details_by_id(self, request, user_id, format=None):
		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			serializer = UserGetSerializer(user_obj,data=request.data)
			if serializer.is_valid():
				serializer.save()
				return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
			return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def delete_user_by_id(self, request, user_id, format=None):
		try:
			user_obj = User.objects.get(id=user_id)
		except:
			user_obj = None
		if user_obj is not None:
			user_obj.is_deleted = True
			user_obj.save()
			return({"data":None, "code":status.HTTP_200_OK, "message":USER_DELETED})
		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})


	def get_all_users_without_pagination(self, request, format=None):
		user_obj = User.objects.filter(role=2, is_deleted=False)
		serializer = UserDetailsSerializer(user_obj, many=True)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})

	def add_user(self, request, format=None):
		serializer = UserCreateUpdateSerializer(data = request.data)
		if serializer.is_valid():
			serializer.save()
			user_obj = User.objects.get(id=serializer.data['id'])
			user_obj.set_password(request.data['password'])
			user_obj.save()
			return({"data":serializer.data, "code":status.HTTP_200_OK, "message":USER_ADDED})
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		