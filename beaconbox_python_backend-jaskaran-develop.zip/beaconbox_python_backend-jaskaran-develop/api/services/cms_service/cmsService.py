#from tara_backend.api.utils.messages.FaqMessages import FAQ_UPDATED
#from api.models import productCategoryModel
from api.models.CMSModel import CMS
from api.models.faqModel import FaqModel
from api.serializers.faqSerializer import CreateUpdateFaqSerializer
# from api.models.AdminFaqModel import FaqModel
from api.serializers.cms import *
from rest_framework import status
from api.utils.messages.commonMessages import *
from api.utils.messages.FaqMessages import *
from api.utils.messages.CmsMessages import *
# from tara_backend.api.models import FaqModel

from .cmsBaseService import CmsBaseService

class CmsService(CmsBaseService):

	def __init__(self):
		pass

	def create_update_cms(self, request, format=None):
		cms = CMS.objects.all().first()
		if cms is None:
			serializer = CreateUpdateCmserializer(data=request.data)
			if serializer.is_valid():
				serializer.save()
				return({"data":None, "code":status.HTTP_200_OK, "message": CMS_CREATED_SUCCESSFULLY})
			return ({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		else:
			serializer = CreateUpdateCmserializer(cms, data=request.data)
			if serializer.is_valid():
				serializer.save()
				return({"data":None, "code":status.HTTP_200_OK, "message": CMS_UPDATED_SUCCESSFULLY})
			return ({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST}) 

	def get_cms(self, request, format=None):
		cms = CMS.objects.all().first()
		if cms is not None:
			serializer = CreateUpdateCmserializer(cms)
			return({"data":serializer.data, "code":status.HTTP_200_OK, "message": OK})
		else:
			data = {'about':"", 'privacy':"",'email':"","contact":'',"address":'',"legal":''}
			return({"data":data, "code":status.HTTP_200_OK, "message": OK})

	def add_update_delete_Faq(self, request, format=None):
		Faq_ids_in_db = FaqModel.objects.all()
		Faq_ids_in_req = []
		for Faq in request.data:
			if 'id' in Faq:
				Faq_ids_in_req.append(Faq['id'])
		print(Faq_ids_in_req)
		for db_id in Faq_ids_in_db:
			if db_id.id not in Faq_ids_in_req:
				doc_obj = FaqModel.objects.get(id=db_id.id)
				doc_obj.delete()
		for Faq in request.data:
			if 'id' not in Faq:
				faq_obj = FaqModel.objects.create(**Faq)
				serializer = CreateUpdateFaqSerializer(faq_obj)
			else:
				try:
					Faq_obj = FaqModel.objects.get(id=Faq['id'])
				except FaqModel.DoesNotExist:
					Faq_obj = None
				if Faq_obj is not None:
					serializer = CreateUpdateFaqSerializer(Faq_obj, data=Faq)
					if serializer.is_valid():
						serializer.save()
					else:
						print('-------------------->> in valid Serializer for {}',Faq['id'])
		return({"data":None, "code":status.HTTP_200_OK, "message":FAQ_UPDATED})

	def get_faq(self, request, format=None):
		try:
			faq_obj =  FaqModel.objects.all()
			serializer= CreateUpdateFaqSerializer(faq_obj,many=True)
			return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
		except FaqModel.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":RECORD_NOT_FOUND})




	