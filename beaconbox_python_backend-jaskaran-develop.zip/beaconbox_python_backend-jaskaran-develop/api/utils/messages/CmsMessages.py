CMS_CREATED_SUCCESSFULLY = "Cms Created successfully"
CMS_UPDATED_SUCCESSFULLY = "Cms Updated Successfully"