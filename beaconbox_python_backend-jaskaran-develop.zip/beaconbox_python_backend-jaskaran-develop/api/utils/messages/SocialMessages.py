SOCIAL_FEATURE_CREATED = "Social Feature Created Successfully"
SOCIAL_FEATURE_UPDATED = "Social Feature Updated Successfully"