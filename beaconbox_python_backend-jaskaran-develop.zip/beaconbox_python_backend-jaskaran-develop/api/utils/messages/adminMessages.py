USER_DEACTIVATED_SUCCESSFULLY = "User Deactivated Successfully."
USER_ACTIVATED_SUCCESSFULLY = "User Activated Successfully."
USER_ADDED = "User Added Successfully."