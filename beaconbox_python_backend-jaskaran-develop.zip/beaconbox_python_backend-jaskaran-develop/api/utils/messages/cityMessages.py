CREATE_CITY = "City created successfully !"
CREATE_STATE = "State created successfully !"
CREATE_COUNTRY = "Country created successfully !"