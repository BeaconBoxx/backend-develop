USER_EMERGENCY_CONTACT_UPDATED="User Emergency Contact Updated"
DELETED="Deleted"
USER_DETAILS_UPDATED="User Details Updated"
