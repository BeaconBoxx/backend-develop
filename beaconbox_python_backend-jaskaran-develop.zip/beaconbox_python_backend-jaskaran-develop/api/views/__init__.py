from .userView import *
from .roleView import *
from .educationHistoryView import *
from .UploadMediaView import *
from .cmsView import *
from .adminView import *
