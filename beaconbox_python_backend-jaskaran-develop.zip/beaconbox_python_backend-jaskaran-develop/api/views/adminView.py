from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.schemas import AutoSchema
from rest_framework.compat import coreapi, coreschema, uritemplate

from api.services.admin import adminServices

adminServices = adminServices.AdminServices()

class AdminGetAllUsersView(APIView):

    def get(self, request,user_id, format=None):
        """
        Get User Profile By ID
        """
        result = adminServices.get_user_by_id(request,user_id, format=None)
        return Response(result, status=result["code"])


    def post(self, request, format=None):
        """
        Get All User with pagination
        """
        result = adminServices.get_all_users(request, format=None)
        return Response(result, status=result["code"])

    def put(self, request,user_id, format=None):
        """
        Get All User with pagination
        """
        result = adminServices.update_user_details_by_id(request,user_id, format=None)
        return Response(result, status=result["code"])

    def delete(self, request,user_id, format=None):
        """
        Get All User with pagination
        """
        result = adminServices.delete_user_by_id(request,user_id, format=None)
        return Response(result, status=result["code"])


class ChangeUserStatusView(APIView):
    def put(self, request,user_id, format=None):
        """
        Change User Status By ID
        """
        result = adminServices.change_user_status_by_id(request,user_id, format=None)
        return Response(result, status=result["code"])

class AdminGetUserWithoutPaginationView(APIView):
    def get(self, request, format=None):
        """
        Get All Users Without Pagination (Export CSV)
        """
        result = adminServices.get_all_users_without_pagination(request, format=None)
        return Response(result, status=result["code"])

class AddUserView(APIView):
    def post(self, request, format=None):
        """
        Add User By Admin
        """

        result = adminServices.add_user(request, format=None)
        return Response(result, status=result["code"])


