from django.db import models
from django.utils import timezone
from simple_history.models import HistoricalRecords


class CMS(models.Model):
    id = models.AutoField(primary_key=True)
    about=models.TextField(blank=True,null=True)
    privacy = models.TextField(blank=True,null=True)
    email = models.CharField(max_length=120,blank=True,null=True)
    contact = models.CharField(max_length=120,blank=True,null =True)
    address = models.TextField(blank =True,null = True)
    legal = models.TextField(blank=True,null = True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(default=timezone.now)
    deleted_at = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    history = HistoricalRecords(table_name='cms_history')


    
    def __str__(self):
        return self.about

    class Meta:
        db_table = 'CMS'
        indexes = [
            models.Index(fields=['id'])
        ]
