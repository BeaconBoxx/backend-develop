from django.db import models
from .userModel import User
from .notificationsModel import Notifications
from django.utils import timezone
class NotificationUser(models.Model):
    '''
    Notification Users
    '''
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='users')
    notification = models.ForeignKey(Notifications, on_delete=models.CASCADE, related_name='notification_users')
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return '%s' % (self.message)
    class Meta:
        db_table = 'notifications_users'
        indexes = [
            models.Index(fields=['id'])
        ]