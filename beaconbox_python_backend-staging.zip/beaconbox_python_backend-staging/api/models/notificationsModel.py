from django.db import models
from .userModel import User

class Notifications(models.Model):
    '''
    Push-Notification
    '''
    id = models.AutoField(primary_key=True)
    # user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_notifications')
    title = models.CharField(max_length=244, null=True, blank=True)
    # extra_args = models.TextField(null=True, blank=True, max_length=1000)
    # sent_args = models.TextField(null=True, blank=True, max_length=1000)
    notification_type = models.CharField(max_length=5, blank=True, null=True)
    notification_mode = models.CharField(max_length=5, blank=True, null=True)
    message = models.TextField(null=True, blank=True, max_length=1000)
    sent_status = models.IntegerField(default=1, blank=True, null=True, help_text="1.pending, 2.Inprogress, 3.success, 4.Error")
    sent_date = models.DateTimeField(null=True, blank=True)
    is_read = models.BooleanField(default=False)
    create_date = models.DateTimeField(auto_now_add=True)
    modify_date = models.DateTimeField(auto_now=True)


    def __str__(self):
        return '%s' % (self.message)

    class Meta:
        db_table = 'notifications'
        indexes = [
            models.Index(fields=['id'])
        ]