# from tkinter.tix import Tree
from django.db import models
from .userModel import User

class PushNotification(models.Model):
    '''
    Push-Notification
    '''
    PENDING = 1
    INPROGRESS = 2
    SUCCESS = 3
    ERROR = 4
    STATUS_CHOICES = {
        (PENDING, 'PENDING'),
        (INPROGRESS, 'INPROGRESS'),
        (SUCCESS, 'SUCCESS'),
        (ERROR, 'ERROR'),
    }
    BOOKING_DONE = 1
    BOOKING_CANCELLED = 2
    MESSAGE_TYPE_CHOICES = (
        (BOOKING_DONE, 'Booking done successfully'),
        (BOOKING_CANCELLED, 'Booking Canceled')
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE,
                             related_name='user_notifications')
    title = models.CharField(max_length=244, null=True, blank=True)
    volume = models.CharField(max_length=10,null=True)
    critical= models.CharField(max_length=10,null=True,blank=True)
    isLocl=models.BooleanField(default=True)
    extra_args = models.TextField(null=True, blank=True, max_length=1000)
    sent_args = models.TextField(null=True, blank=True, max_length=1000)
    notification_type = models.CharField(max_length=500, blank=True, null=True)
    message = models.TextField(null=True, blank=True, max_length=1000)
    sent_status = models.SmallIntegerField(default=3, blank=True, null=True, help_text="1.pending, 2.Inprogress, 3.success, 4.Error")
    sent_date = models.DateTimeField(null=True, blank=True)
    is_read = models.BooleanField(default=False)
    create_date = models.DateTimeField(auto_now_add=True)
    modify_date = models.DateTimeField(auto_now=True)


    def __str__(self):
        return '%s' % (self.message)

    class Meta:
        db_table = 'push_notifications'
        indexes = [
            models.Index(fields=['id'])
        ]