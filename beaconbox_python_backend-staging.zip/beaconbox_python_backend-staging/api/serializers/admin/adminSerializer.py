from api.models.emergencyActionsModel import EmergencyActions
from api import models
from api.models.notificationsModel import Notifications
from api.models.notificationUserModel import NotificationUser
from api.utils.notifications.notification import Notification
from api.models.pushNotificationModel import PushNotification
from django.db.models import fields
from rest_framework import serializers
from api.models import (User, Branch, Classes, ClassSection, UserClassDetails, UserSectionDetails, EmergencyProtocol)

from django.core.exceptions import ValidationError
from beacon_box.settings import TIME12HRSFORMAT, DATEFORMAT
from api.serializers.uploadMedia import UploadMediaDetailsSerializer
from api.utils.notifications.utility import NotificationMessages as notification_message
from beacon_box import settings
from django.core.mail import send_mail

class UserDetailsSerializer(serializers.ModelSerializer):
	"""
	Return the details of Login User.
	"""
	full_name = serializers.SerializerMethodField()
	image = UploadMediaDetailsSerializer()
	heart_rate = serializers.SerializerMethodField()
	spo2 = serializers.SerializerMethodField()
	heart_rate_variability = serializers.SerializerMethodField()

	class Meta(object):
		model = User
		fields = (
		'id', 'email', 'first_name', 'last_name', 'phone_no','dob', 'is_active',"image","heart_rate","spo2","heart_rate_variability","full_name")

	def get_full_name(self, obj):
		try:
			if obj.middle_name is None or obj.middle_name == '' :
				if obj.last_name is None:
					if obj.first_name is None:
						return ''
					else:
						return obj.first_name	
				else:
					return obj.first_name + ' ' + obj.last_name
			else:
				return obj.first_name + ' ' + obj.middle_name + ' ' + obj.last_name
		except:
			return ''

	def get_spo2(self, obj):
		try:
			res = obj.min_spo2 + ' - ' + obj.max_spo2
			return res
		except:
			return '-'
	def get_heart_rate(self, obj):
		try:
			res = obj.min_heart_rate + ' - ' + obj.max_heart_rate
			return res
		except:
			return '-'

	def get_heart_rate_variability(self, obj):
		try:
			res = obj.min_heart_rate_variability + ' - ' + obj.max_heart_rate_variability
			return res
		except:
			return '-'


class UserNotificationSerializer(serializers.ModelSerializer):
	class Meta(object):
		model = NotificationUser
		fields = ('id', 'user')

class GetUserNotificationSerializer(serializers.ModelSerializer):

	full_name = serializers.SerializerMethodField() 
	class Meta(object):
		model = NotificationUser
		fields = ('id', 'user','full_name')

	def get_full_name(self, obj):
		try:
			if obj.user.middle_name is None or obj.user.middle_name == '' :
				if obj.user.last_name is None:
					if obj.user.first_name is None:
						return ''
					else:
						return obj.user.first_name	
				else:
					return obj.user.first_name + ' ' + obj.user.last_name
			else:
				return obj.user.first_name + ' ' + obj.user.middle_name + ' ' + obj.user.last_name
		except:
			return ''





class GetAllPushNotification(serializers.ModelSerializer):
	
	full_name = serializers.SerializerMethodField()
	notification_mode = serializers.SerializerMethodField()
	notification_users = GetUserNotificationSerializer(many=True)
	# notification_mode = serializers.SerializerMethodField()
	class Meta(object):

		model = Notifications
		fields = (
		'id', 'title', 'message',"full_name","notification_mode","notification_users", "create_date")

	def get_full_name(self, obj):
		# try:
		# 	if obj.user.middle_name is None or obj.user.middle_name == '' :
		# 		if obj.user.last_name is None:
		# 			if obj.user.first_name is None:
		# 				return ''
		# 			else:
		# 				return obj.user.first_name	
		# 		else:
		# 			return obj.user.first_name + ' ' + obj.user.last_name
		# 	else:
		# 		return obj.user.first_name + ' ' + obj.user.middle_name + ' ' + obj.user.last_name
		# except:
		# 	return ''
		return 'Test'

	def get_notification_mode(self, obj):
		if obj.notification_mode == '1':
			return 'Email'
		elif obj.notification_mode == '2':
			return 'Push Notification'



class CreateNotificationsSerialzier(serializers.ModelSerializer):
	notification_users = UserNotificationSerializer(many=True)
	class Meta(object):
		model = Notifications
		fields = ('id', 'notification_type','notification_mode','title','message','is_read','notification_users')

	def create(self, validated_data):
		notification_data = Notifications()
		notification_data.notification_type = validated_data['notification_type']
		notification_data.notification_mode = validated_data['notification_mode']
		notification_data.title = validated_data['title']
		notification_data.message = validated_data['message']
		if 'is_read' in validated_data:
			notification_data.is_read = validated_data['is_read']
		notification_data.save()
		all_emails = []
		for user in validated_data['notification_users']:
			Message = validated_data['message']
			title = validated_data['title']
			if notification_data.notification_mode == '2':
				notification_message.send_push_notification(user['user'], title, Message)
			else:
				print(user["user"].email)
				all_emails.append(user["user"].email)
			NotificationUser.objects.create(notification=notification_data, **user)
		try:
			print('--------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
			print(all_emails)
			from_email = settings.EMAIL_HOST_USER
			to_email = user['user'].email
			send_mail(title, Message, from_email,all_emails, fail_silently=False)
		except:
			None

		return notification_data




class GetAllUsersSerializer(serializers.ModelSerializer):
	

	full_name = serializers.SerializerMethodField()
	class Meta(object):
		model = User
		fields = ('id','full_name')

	def get_full_name(self, obj):
		try:
			if obj.middle_name is None or obj.middle_name == '' :
				if obj.last_name is None:
					if obj.first_name is None:
						return ''
					else:
						return obj.first_name	
				else:
					return obj.first_name + ' ' + obj.last_name
			else:
				return obj.first_name + ' ' + obj.middle_name + ' ' + obj.last_name
		except:
			return ''


class CreateGetEmergencyActionsSerializer(serializers.ModelSerializer):
	
	class Meta(object):
		model = EmergencyActions
		fields = ('id','name','description')


class CreateGetEmergencyProtocolSerializer(serializers.ModelSerializer):
	
	class Meta(object):
		model = EmergencyProtocol
		fields = ('id','action','timer','sequence_id','message')

class GetEmergencyProtocolSerializer(serializers.ModelSerializer):

	action  = CreateGetEmergencyActionsSerializer()
	
	class Meta(object):
		model = EmergencyProtocol
		fields = ('id','action','timer','sequence_id','message')