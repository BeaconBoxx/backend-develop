from rest_framework import serializers
from api.models.CMSModel import CMS

class CreateUpdateCmserializer(serializers.ModelSerializer):
	"""
	This is for create/upadate cms
	"""
	class Meta(object):
		model = CMS
		fields = ('id','about','privacy','email','contact','address','legal')

	def create(self, validated_data):
		"""
		Create New CMS details
		"""
		cms = CMS()
		cms.about = validated_data['about'] if 'about' in validated_data else ""
		cms.privacy = validated_data['privacy'] if 'privacy' in validated_data else ""
		cms.email = validated_data['email'] if 'email' in validated_data else ""
		cms.contact = validated_data['contact'] if 'contact' in validated_data else ""
		cms.address = validated_data['address'] if 'address' in validated_data else ""
		cms.legal = validated_data['legal'] if 'legal' in validated_data else ""
		cms.save()
		return cms
	
	def update(self, instance, validated_data):
		"""
		update CMS details
		"""
		if 'about' in validated_data:
			instance.about = validated_data['about']
		if 'privacy' in validated_data:
			instance.privacy = validated_data['privacy']
		if 'email' in validated_data:
			instance.email = validated_data['email']
		if 'contact' in validated_data:
			instance.contact = validated_data['contact']
		if 'address' in validated_data:
			instance.address = validated_data['address']
		if 'legal' in validated_data:
			instance.legal = validated_data['legal']
		instance.save()
		return instance

