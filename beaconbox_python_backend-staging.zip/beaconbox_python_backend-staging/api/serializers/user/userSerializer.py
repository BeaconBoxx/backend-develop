from api.models.alarmModel import AlarmModel
from api.models.emergencyContacts import EmergencyContacts
from django.db.models import fields
from rest_framework import serializers
from api.models import (User, Branch, Classes, ClassSection, UserClassDetails, UserSectionDetails)

from django.core.exceptions import ValidationError
from beacon_box.settings import TIME12HRSFORMAT, DATEFORMAT
from api.serializers.uploadMedia import UploadMediaDetailsSerializer

class UserLoginDetailSerializer(serializers.ModelSerializer):
    """
    Return the details of Login User.
    """
    # dob = serializers.DateField(format=DATEFORMAT, input_formats=[DATEFORMAT])
    image = UploadMediaDetailsSerializer()
    class Meta(object):
        model = User
        fields = (
        'id', 'email', 'first_name', 'last_name', 'phone_no', 'is_active', 'is_deleted', "profile_status", "country_code", "image")

class CreateUpdateUserSectionDetailsSerializer(serializers.ModelSerializer):
    """
    create/update user class Details
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = UserSectionDetails
        fields = ("id", "section")

class CreateUpdateUserClassDetailsSerializer(serializers.ModelSerializer):
    """
    create/update user class Details
    """
    id = serializers.IntegerField(required=False)
    user_sections = CreateUpdateUserSectionDetailsSerializer(many=True)
    class Meta:
        model = UserClassDetails
        fields = ("id", "classes", "branch", "user_sections")

class UserGetSerializer(serializers.ModelSerializer):
    """
    create/update user .
    """
    id = serializers.IntegerField(required=False)
    image = UploadMediaDetailsSerializer()
    emergency_contacts_count = serializers.SerializerMethodField()
    is_snooze = serializers.SerializerMethodField()
    class Meta:
        model = User
        fields = ('id', 'first_name','last_name', 'middle_name', 'phone_no', 'email', 'country_code', 'role', 'gender', 'address', 'address2','longitude', 'latitude', 'image','city', 'state', 'country', 'zip_code', 'lock_box_code','property_access_code', 'medical_information', 'location_directions','min_heart_rate', 'max_heart_rate', 'min_spo2','max_spo2', 'min_heart_rate_variability', 'max_heart_rate_variability','dob',"is_social",'social_type','emergency_contacts_count', "profile_status","encoded_id","fitbit_id","appleWatchID",'is_fitbit_installed','fitbit_name','is_snooze')

    def get_emergency_contacts_count(self, obj):
        emergency_obj = EmergencyContacts.objects.filter(user = obj.id).count()
        return emergency_obj

    def get_is_snooze(self, obj):

        try:

            sn_obj = AlarmModel.objects.get(user = obj.id)
            return sn_obj.is_snooze
        except AlarmModel.DoesNotExist:
            return None

class UserSubSerializer(serializers.ModelSerializer):
    """
    create/update user .
    """
    # id = serializers.IntegerField(required=False)
    # image = UploadMediaDetailsSerializer()
    class Meta:
        model = User
        fields = ("sub_id","sub_start_date","sub_end_date","sub_price")

class GetUserDetailsWithSubSerializer(serializers.ModelSerializer):
    """
    create/update user .
    """
    id = serializers.IntegerField(required=False)
    # sub_details = UserSubSerializer()
    # image = UploadMediaDetailsSerializer()
    class Meta:
        model = User
        fields = ('id', 'first_name','last_name', 'middle_name', 'phone_no', 'email','user_name', 'country_code', 'role', 'gender', 'address', 'longitude', 'latitude', 'image','city', 'state', 'country', 'zip_code', 'lock_box_code','property_access_code', 'medical_information', 'location_directions','min_heart_rate', 'max_heart_rate', 'min_spo2','max_spo2', 'min_heart_rate_variability', 'max_heart_rate_variability','dob','fitbit_id','appleWatchID',
        'is_fitbit_installed','fitbit_name')

 #
class UserCreateUpdateSerializer(serializers.ModelSerializer):
    """
    create/update user .
    """
    id = serializers.IntegerField(required=False)
    # image = UploadMediaDetailsSerializer()
    class Meta:
        model = User
        fields = ('id', 'first_name','last_name', 'middle_name', 'phone_no', 'email','user_name', 'country_code', 'role', 'gender', 'address','address2','longitude', 'latitude', 'image','city', 'state', 'country', 'zip_code', 'lock_box_code','property_access_code', 'medical_information', 'location_directions','min_heart_rate', 'max_heart_rate', 'min_spo2','max_spo2', 'min_heart_rate_variability', 'max_heart_rate_variability','dob','fitbit_id','appleWatchID',
        'is_fitbit_installed','fitbit_name')

    def update(self, instance, validated_data):
        
        if 'first_name' in validated_data:
            instance.first_name = validated_data['first_name']
        if 'last_name' in validated_data:
            instance.last_name = validated_data['last_name']
        if 'middle_name' in validated_data:
            instance.middle_name = validated_data['middle_name']
        if 'fitbit_id' in validated_data:
            instance.fitbit_id = validated_data['fitbit_id']
        if 'appleWatchID' in validated_data:
            instance.appleWatchID = validated_data['appleWatchID']
        if 'fitbit_name' in validated_data:
            instance.fitbit_name = validated_data['fitbit_name']
        if 'email' in validated_data:
            instance.email = validated_data['email']
        if 'country_code' in validated_data:
            instance.country_code = validated_data['country_code']
        if 'phone_no' in validated_data:
            instance.phone_no = validated_data['phone_no']
        if 'address' in validated_data:
            instance.address = validated_data['address']
        if 'address2' in validated_data:
            instance.address2 = validated_data['address2']
        if 'longitude' in validated_data:
            instance.longitude = validated_data['longitude']
        if 'latitude' in validated_data:
            instance.latitude = validated_data['latitude']
        if 'gender' in validated_data:
            instance.gender = validated_data['gender']
        
        if 'image' in validated_data:
            instance.image = validated_data['image']

        if 'city' in validated_data:
            instance.city = validated_data['city']
        if 'state' in validated_data:
            instance.state = validated_data['state']
        if 'country' in validated_data:
            instance.country = validated_data['country']
        if 'zip_code' in validated_data:
            instance.zip_code = validated_data['zip_code']
        if 'lock_box_code' in validated_data:
            instance.lock_box_code = validated_data['lock_box_code']
        if 'property_access_code' in validated_data:
            instance.property_access_code = validated_data['property_access_code']
        if 'medical_information' in validated_data:
            instance.medical_information = validated_data['medical_information']
        if 'location_directions' in validated_data:
            instance.location_directions = validated_data['location_directions']

        if 'min_heart_rate' in validated_data:
            instance.min_heart_rate = validated_data['min_heart_rate']
        if 'max_heart_rate' in validated_data:
            instance.max_heart_rate = validated_data['max_heart_rate']
        if 'min_spo2' in validated_data:
            instance.min_spo2 = validated_data['min_spo2']
        if 'max_spo2' in validated_data:
            instance.max_spo2 = validated_data['max_spo2']
        if 'min_heart_rate_variability' in validated_data:
            instance.min_heart_rate_variability = validated_data['min_heart_rate_variability']
        if 'max_heart_rate_variability' in validated_data:
            instance.max_heart_rate_variability = validated_data['max_heart_rate_variability']

        if 'dob' in validated_data:
            instance.dob = validated_data['dob']
        if 'role' in validated_data:
            instance.role = validated_data['role']
        # instance.encoded_id = None
        instance.is_active = True
        if "profile_status" in validated_data:
            instance.profile_status = validated_data["profile_status"]
        # instance.profile_status = 3
        instance.save()
        return instance

class UserVitalsSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id','min_heart_rate', 'max_heart_rate', 'min_spo2','max_spo2', 'min_heart_rate_variability', 'max_heart_rate_variability')
    
    def update(self, instance, validated_data):
        if 'min_heart_rate' in validated_data:
            instance.min_heart_rate = validated_data['min_heart_rate']
        if 'max_heart_rate' in validated_data:
            instance.max_heart_rate = validated_data['max_heart_rate']
        if 'min_spo2' in validated_data:
            instance.min_spo2 = validated_data['min_spo2']
        if 'max_spo2' in validated_data:
            instance.max_spo2 = validated_data['max_spo2']
        if 'min_heart_rate_variability' in validated_data:
            instance.min_heart_rate_variability = validated_data['min_heart_rate_variability']
        if 'max_heart_rate_variability' in validated_data:
            instance.max_heart_rate_variability = validated_data['max_heart_rate_variability']

        instance.save()
        return instance

class CreateBranchesSerializer(serializers.ModelSerializer):
    """
    create branches
    """
    class Meta:
        model = Branch
        fields = ("id", "name")

class CreateClassesSerializer(serializers.ModelSerializer):
    """
    create classes
    """
    class Meta:
        model = Classes
        fields = ("id", "name", "branch")


class CreateClassSectionSerializer(serializers.ModelSerializer):
    """
    create class sections
    """
    class Meta:
        model = ClassSection
        fields = ("id", "name", "section_class")



class GetBranchesSerializer(serializers.ModelSerializer):
    """
    Get branches
    """
    class Meta:
        model = Branch
        fields = ("id", "name")

class GetClassesSerializer(serializers.ModelSerializer):
    """
    Get classes
    """
    branch = GetBranchesSerializer()
    class Meta:
        model = Classes
        fields = ("id", "name", "branch")


class GetClassSectionSerializer(serializers.ModelSerializer):
    """
    Get class sections
    """
    section_class = GetClassesSerializer()
    class Meta:
        model = ClassSection
        fields = ("id", "name", "section_class")


class GetUserSectionDetailsSerializer(serializers.ModelSerializer):
    """
    Get user class Details
    """
    section = GetClassSectionSerializer()
    class Meta:
        model = UserSectionDetails
        fields = ("id", "section")

class GetUserClassDetailsSerializer(serializers.ModelSerializer):
    """
    Get user class Details
    """
    user_sections = GetUserSectionDetailsSerializer(many=True)
    classes = GetClassesSerializer()
    branch = GetBranchesSerializer()
    class Meta:
        model = UserClassDetails
        fields = ("id", "classes", "branch", "user_sections")

class UserDetialsSerializer(serializers.ModelSerializer):
    """
    Get user Detials.
    """
    user_classes = GetUserClassDetailsSerializer(many=True)
    class Meta:
        model = User
        fields = ('id', 'first_name', 'wristband_id', 'phone_no', 'email', 'country_code', 'role', 'gender', 'address', 'longitude', 'latitude', 'image', "user_classes", "is_approved")

class UserUpdateDetialsSerializer(serializers.ModelSerializer):
    """
    create/update user.
    """
    id = serializers.IntegerField(required=False)
    user_classes = CreateUpdateUserClassDetailsSerializer(many=True)
    class Meta:
        model = User
        fields = ('id', 'first_name', 'wristband_id', 'phone_no', 'email', 'country_code', 'role', 'gender', 'address', 'longitude', 'latitude', 'image', "user_classes")       

    def update(self, instance, validated_data):
        instance.first_name = validated_data['first_name']
        instance.wristband_id = validated_data['wristband_id']
        instance.email = validated_data['email']
        instance.country_code = validated_data['country_code']
        instance.phone_no = validated_data['phone_no']
        instance.address = validated_data['address']
        if 'longitude' in validated_data:
            instance.longitude = validated_data['longitude']
        if 'latitude' in validated_data:
            instance.latitude = validated_data['latitude']
        instance.gender = validated_data['gender']
        instance.role = validated_data['role']
        instance.image = validated_data['image']
        instance.encoded_id = None
        instance.is_active = True
        instance.profile_status = 4
        instance.save()

        self.update_user_classes(instance, validated_data["user_classes"])

        return instance
    
    def update_user_classes(self, instance, user_classes_data):
        user_classes_ids = []
        for row in user_classes_data:
            if "id" in row:
                user_classes_ids.append(row["id"])
    
        user_class_list = UserClassDetails.objects.filter(user=instance)
        for user_class in user_class_list:
            if user_class.id not in user_classes_ids:
                UserClassDetails.objects.get(id=user_class.id).delete()
        
        for user_class in user_classes_data:
            user_class_id = user_class.get("id")
            try:
                user_class_obj = UserClassDetails.objects.get(id=user_class_id)
                user_class_obj.classes = user_class["classes"]
                user_class_obj.branch = user_class["branch"]
                user_class_obj.save()
                self.update_user_sections(user_class_obj, user_class["user_sections"])
            except UserClassDetails.DoesNotExist:
                sections = user_class.pop("user_sections")
                class_details_obj = UserClassDetails.objects.create(user=instance, **user_class)
                for section_data in sections:
                    UserSectionDetails.objects.create(user_class=class_details_obj, **section_data)
        
        return 'success'
    

    def update_user_sections(self, instance, user_sections_data):
        user_sections_ids = []
        for row in user_sections_data:
            if "id" in row:
                user_sections_ids.append(row["id"])
    
        user_sections_list = UserSectionDetails.objects.filter(user_class=instance)
        for user_sections in user_sections_list:
            if user_sections.id not in user_sections_ids:
                UserSectionDetails.objects.get(id=user_sections.id).delete()
        
        for user_sections in user_sections_data:
            user_section_id = user_sections.get("id")
            try:
                user_section_obj = UserSectionDetails.objects.get(id=user_section_id)
                user_section_obj.section = user_sections["section"]
                user_section_obj.save()
            except UserSectionDetails.DoesNotExist:
                UserSectionDetails.objects.create(user_class=instance, **user_sections)
        
        return 'success'

class GetUpdateEmergencyContactsSerializer(serializers.ModelSerializer):
    """
    create/update Emergency Contacts.
    """
    id = serializers.IntegerField(required=False)
    class Meta:
        model = EmergencyContacts
        fields = ('id', 'contact_number', 'contact_name')       
