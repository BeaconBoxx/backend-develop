from abc import ABC, abstractmethod


class CmsBaseService(ABC):

    @abstractmethod
    def create_update_cms(self):
        """ Abstract method to create cms """
        pass