from os import sendfile
from api.models.UploadMediaModel import UploadMedia
from api.models.emergencyContacts import EmergencyContacts
from rest_framework import status
from rest_framework.response import Response
from rest_framework_jwt.settings import api_settings
from django.template.loader import render_to_string
# from twilio.rest import Client
import json
import base64
import random
from django.core.mail import send_mail
# from django.core.exceptions import BadRequest, ValidationError
from django.contrib.auth import authenticate, login
from django.core.mail import EmailMultiAlternatives
import pytz
from datetime import datetime, timedelta
import jwt
jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER

from django.core.files.base import ContentFile

from .userBaseService import UserBaseService
from api.utils.messages.userMessages import *
from api.utils.messages.commonMessages import *
from api.models import User, UserSession, Role, UserClassDetails, AlarmModel
from api.utils.getUserByToken import get_user_by_token
from api.serializers.user import *
from beacon_box import settings
from twilio.rest import Client
from decouple import config
from api.utils.notifications.utility import NotificationMessages as notification_message
from api.utils.sendEmergencyMessage import send_twillio_emergency_message
import time as duration_time


volume = 3
critical = 0
flag = 0 

from api.models import PushNotification as NotificationModel
class UserService(UserBaseService):
	"""
	Allow any user (authenticated or not) to access this url 
	"""

	def __init__(self):
		pass

	def login(self, request, role, format=None):

		validated_data = self.validate_auth_data(request)

		if "email" in request.data:
			username = request.data['email'].lower()
			country_code = None
		else:
			username = request.data['phone_no']
			country_code = request.data['country_code']

		if 'password' in request.data:
			password = request.data['password']
		else:
			password = ''

		print('---------------------_>>>')
		print(role)
		print(username)
		print(country_code)
		print(password)
		print('2345678')
		if 'social_login_id' in request.data:
			try:
				user = User.objects.get(social_login_id=request.data['social_login_id'])
			except User.DoesNotExist:
				user = None
		else:
			user = self.user_authenticate(username, password, role, country_code)
		
		if user is not None:
			
			login(request, user)

			serializer = UserGetSerializer(user)

			payload = jwt_payload_handler(user)
			token = jwt.encode(payload, settings.SECRET_KEY)

			user_details = serializer.data
			if user.profile_status == 4:
				user_details['token'] = token
				# User.objects.filter(pk=user.pk).update(auth_token=token)

				user_session = self.create_update_user_session(user, token, request)

			return ({"data": user_details,"code": status.HTTP_200_OK,"message": "LOGIN SUCCESSFULLY"})
		return ({"data": None,"code": status.HTTP_400_BAD_REQUEST, "message": "INVALID CREDENTIALS"})

	def user_authenticate(self, user_name, password, role, country_code):
		try:
			user = User.objects.get(email=user_name, role__in=role)
			print(user)
			if user.is_social == True:
				return user
			if user.check_password(password):
				return user # return user on valid credentials
		except User.DoesNotExist:
			try:
				user = User.objects.get(phone_no=user_name, country_code=country_code, role__in=role)
				print(user)
				print('wsdfvefg')
				if user.check_password(password):
					print('authenticate')
					return user # return user on valid credentials
				print(' not authenticate')
			except User.DoesNotExist:
				return None

	def validate_auth_data(self, request):
		error = {}
		# if not request.data.get('email'):
		# 	error.update({'email' : "FIELD_REQUIRED" })

		# if not request.data.get('password'):
		# 	error.update({'password' : "FIELD_REQUIRED" })

		if request.headers.get('device-type')=='android'or request.headers.get('device-type')=='ios':
			if not request.data.get('device_id'):
				error.update({'device_id': "FIELD_REQUIRED"})

		if error:
			raise ValidationError(error)
	
	def create_update_user_session(self, user, token, request):
		"""
		Create User Session
		"""
		user_session = self.get_user_session_object(user.pk, request.headers.get('device-type'), request.headers.get('device-id'))

		if user_session is None:
			UserSession.objects.create(
				user = user,
				token = token,
				device_id = request.headers.get('device-id'),
				device_type = request.headers.get('device-type'),
				device_token = request.headers.get('device-token'),
				app_version = request.headers.get('app-version')
			)

		else:

			user_session.token = token
			user_session.app_version = request.headers.get('app-version')
			user_session.device_token = request.headers.get('device-token')
			user_session.save()

		return user_session

	
	def get_user_session_object(self, user_id, device_type, device_id=None):
		try:
			if device_id:
				try:
					return UserSession.objects.get(user=user_id, device_type=device_type, device_id=device_id)
				except UserSession.DoesNotExist:
					user_obj = UserSession.objects.filter(user=user_id)
					if len(user_obj) > 0 :
						user_obj.delete()
					return None
			else:
				try:
					return UserSession.objects.get(user=user_id, device_type=device_type, device_id=device_id)
				except :
					user_obj = UserSession.objects.filter(user=user_id)
					if len(user_obj) > 0 :
							user_obj.delete()
					return None

				

		except UserSession.DoesNotExist:
			return None

	def generate_encoded_id(self, obj):
		encoded_id = base64.b64encode(str(random.randint (10000000, 99990000)).encode("ascii")).decode("ascii")
		obj.encoded_id = encoded_id
		obj.save()
		return "success"

	def send_otp_on_mail(self, email):
		print(email)
		try:
			member_time_zone = "UTC"
			tz = pytz.timezone(member_time_zone)

			current_time = datetime.now(tz)
			try:
				user = User.objects.get(email=email.lower())
			except User.DoesNotExist:
				raise Exception ({
					'email': EMAIL_NOT_EXIST
				})

			otp = random.randint (1000, 9999)
			user.otp = otp
			user.otp_varification = False
			user.otp_send_time = current_time
			user.save ()
			context = {"otp":otp}
			body_msg = render_to_string ('api/email/email-confirmation.html', context)
			sender = config('EMAIL_HOST_USER')
			default_from_email = config('DEFAULT_FROM_EMAIL')
			msg = EmailMultiAlternatives ("Email Varification<Don't Reply>", body_msg, "rishabjaitly@apptunix.com", [email])
			msg.content_subtype = "html"
			msg.send()


			return "Success"
		except Exception as e:
			print(e)
			pass

	def send_mobile_otp(self, user):
		try:
			tz = pytz.timezone ('Asia/Kolkata')
			current_time = datetime.now (tz)

			# user = self.get_object_by_email (email)
			otp = random.randint (100000, 999999)
			body_msg = 'Your OTP is {} . OTP is valid for 1 hour or 1 successfull attempt.'.format (
				otp)
			account_sid = "AC3c90cc753940be88466d44fa3066cf23"
			auth_token = "fdc70d87eac59a4074bc9cf54d0cc336"
			# client = Client(account_sid, auth_token)
			# message = client.messages.create(
			#         to="+91{}".format("8146664616"), 
			#         from_="+18152013322",
			#         body=body_msg)

			user.otp = 1234
			user.otp_send_time = current_time
			user.save ()

			
		except Exception as e:
			raise ValidationError(e)

	def sign_up(self, request, format=None):
		role = Role.objects.get(id=2)
		if "social_login_id" in request.data and  'social_type' in request.data:
			try:
				user = User.objects.get(social_login_id=request.data['social_login_id'])
				if user.profile_status == 4:
					serializer = UserLoginDetailSerializer(user)
					payload = jwt_payload_handler(user)
					token = jwt.encode(payload, settings.SECRET_KEY)
					user_details = serializer.data
					user_details['token'] = token
					user_session = self.create_update_user_session(user, token, request)
					return({"data":user_details, "code":status.HTTP_200_OK, "message":SOCIAL_LOGIN_SUCCESSFULL})	
				else:
					data = {"user":user.encoded_id, "profile_status":user.profile_status}
					return({"data":data, "code":status.HTTP_200_OK, "message":SOCIAL_LOGIN_SUCCESSFULL})
				
			except User.DoesNotExist:
				if 'email' in request.data:
					try:
						user = User.objects.get(email=request.data['email'])
						return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":EMAIL_ALREADY_EXIST})
					except User.DoesNotExist:
						pass

					
				if 'email' not in request.data:
					role = Role.objects.get(id=2)
					user = User.objects.create(user_name = request.data["social_login_id"], profile_status=2, role=role)
				else:
					user = User.objects.create(email=request.data["email"].lower(), user_name = request.data["social_login_id"], profile_status=2, role=role)
				user.is_social = request.data['is_social']
				user.social_type = request.data['social_type']
				user.social_login_id = request.data['social_login_id']
				user.otp_varification = True
				if 'first_name' in request.data:
					user.first_name = request.data['first_name']
				if 'last_name' in request.data:
					user.last_name = request.data['last_name']
				if 'image' in request.data:
					image_obj = UploadMedia.objects.get(id=request.data['image'])
					user.image = image_obj
				 

				
				user.save()
				self.generate_encoded_id(user)
				{"encoded_id":user.encoded_id}
				# self.send_otp_on_mail(request.data["email"])
				return({"data":{"user":user.encoded_id}, "code":status.HTTP_200_OK, "message":SOCIAL_LOGIN_SUCCESSFULL})
		
		elif "email" in request.data:
			try:
				user = User.objects.get(email=request.data["email"].lower())
				self.generate_encoded_id(user)
				if int(user.profile_status) == 4:
					return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":EMAIL_ALREADY_EXIST})
				else:
					self.send_otp_on_mail(request.data["email"])
					return({"data":None, "code":status.HTTP_200_OK, "message":OTP_SENT})
			except User.DoesNotExist:
				if 'is_social' in request.data and 'social_type' in request.data:
					user = User.objects.create(email=request.data["email"].lower(), user_name = request.data["email"], profile_status=1, role=role)
					user.is_social = request.data['is_social']
					user.social_type = request.data['social_type']
					user.social_login_id = request.data['social_login_id']
					
					user.save()
					self.generate_encoded_id(user)
					self.send_otp_on_mail(request.data["email"])
					return({"data":None, "code":status.HTTP_200_OK, "message":OTP_SENT})
				
				else:

					user = User.objects.create(email=request.data["email"].lower(), user_name = request.data["email"], profile_status=1, role=role)
					user.set_password(request.data['password'])
					user.save()
					self.generate_encoded_id(user)
					self.send_otp_on_mail(request.data["email"])
					return({"data":None, "code":status.HTTP_200_OK, "message":OTP_SENT})
		else:
			try:
				user = User.objects.get(phone_no=request.data["phone_no"],country_code = request.data["country_code"])
				self.generate_encoded_id(user)
				if int(user.profile_status) == 4:
					return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":PHONE_ALREADY_EXIST})
				else:
					res = self.send_twillio_message(user)
					if res == False:
						return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"Please enter a valid phone number!"})	
					return({"data":None, "code":status.HTTP_200_OK, "message":OTP_SENT})
			except User.DoesNotExist:
				user = User.objects.create(country_code = request.data["country_code"], phone_no=request.data["phone_no"], user_name=request.data["phone_no"], profile_status=1, role=role)
				user.set_password(request.data['password'])
				user.save()
				self.generate_encoded_id(user)
				res = self.send_twillio_message(user)
				if res == False:
						return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"Please enter a valid phone number!"})	
				return({"data":None, "code":status.HTTP_200_OK, "message":OTP_SENT})
	
	def touch_id_login(self, request, format=None):
		try:
			user = User.objects.get(id=request.data['id'])
		except:
			user = None
		if user is not None:
			if user.profile_status == 4:
				login(request, user)
				serializer = UserLoginDetailSerializer(user)
				payload = jwt_payload_handler(user)
				token = jwt.encode(payload, settings.SECRET_KEY)
				user_details = serializer.data
				user_details['token'] = token
				user_session = self.create_update_user_session(user, token, request)
				return({"data":user_details, "code":status.HTTP_200_OK, "message":"User Logged in Successfully."})
			else:
				data = {"user":user.encoded_id, "profile_status":user.profile_status}
				return({"data":data, "code":status.HTTP_200_OK, "message":"User Logged in Successfully."})
		else:
			return({"data":None, "code":status.HTTP_204_NO_CONTENT, "message":RECORD_NOT_FOUND})




	
	
	def validate_signup_data(self, data):
		try:
			user = User.objects.get(phone_no=data.get('phone_no'))
			raise ValidationError({"phone_no": "you are already registered with this phone no. if you not remeber your password then click on Forgot Passowrd!!"})
		except User.DoesNotExist:
			return None

	# def send_otp(self, user):
	# 	try:
	# 		tz = pytz.timezone ('Asia/Kolkata')
	# 		current_time = datetime.now (tz)

	# 		# user = self.get_object_by_email (email)
	# 		otp = random.randint (100000, 999999)
	# 		body_msg = 'Your OTP is {} . OTP is valid for 1 hour or 1 successfull attempt.'.format (
	# 			otp)
	# 		account_sid = "AC3c90cc753940be88466d44fa3066cf23"
	# 		auth_token = "fdc70d87eac59a4074bc9cf54d0cc336"
	# 		# client = Client(account_sid, auth_token)
	# 		# message = client.messages.create(
	# 		#         to="+91{}".format("8146664616"), 
	# 		#         from_="+18152013322",
	# 		#         body=body_msg)

	# 		user.otp = 1102
	# 		user.otp_send_time = current_time
	# 		user.save ()

			
	# 	except Exception as e:
	# 		raise ValidationError(e)
	
	def send_otp_for_old_user(self, request, format=None):
		try:
			tz = pytz.timezone ('Asia/Kolkata')
			current_time = datetime.now (tz)
			if "email" in request.data and len(request.data["email"]) != 0:
				try:
					user = User.objects.get(email=request.data["email"])
					self.send_otp_on_mail(user.email)
					return ({"data":None, "code":status.HTTP_200_OK, "message":OTP_SENT})
				except User.DoesNotExist:
					return ({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":RECORD_NOT_FOUND})
			else:
				try:
					user = User.objects.get(phone_no=request.data["phone_no"], country_code = request.data["country_code"])
				except User.DoesNotExist:
					return ({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":RECORD_NOT_FOUND})

			otp = random.randint (1000, 9999)
			body_msg = 'Your OTP is {} . OTP is valid for 1 hour or 1 successfull attempt.'.format (
				otp)
			account_sid = "AC3c90cc753940be88466d44fa3066cf23"
			auth_token = "fdc70d87eac59a4074bc9cf54d0cc336"
			# client = Client(account_sid, auth_token)
			# message = client.messages.create(
			#         to="+91{}".format("8146664616"), 
			#         from_="+18152013322",
			#         body=body_msg)
			user.otp_varification = False
			user.otp = 1234
			user.otp_send_time = current_time
			user.save()

			print("-----------------------otp-----------------------")
			print(user.otp)

			
		except Exception as e:
			raise ValidationError(e)

		return ({"data":None, "code":status.HTTP_200_OK, "message":"OTP Sent Successfully"})

	def verify_otp(self, request, format=None):
		# self.validate_otp_data (request.data)
		tz = pytz.timezone ('Asia/Kolkata')
		current_time = datetime.now (tz)
		now_date = current_time.strftime ('%m/%d/%y')
		now_time = current_time.strftime ('%H:%M')

		otp = request.data['otp']
		user = None
		if "email" in request.data and len(request.data["email"]) != 0:
			try:
				user = User.objects.get(email=request.data["email"])
			except User.DoesNotExist:
				user = None
		else:
			try:
				user = User.objects.get(phone_no=request.data["phone_no"], country_code = request.data["country_code"])
			except User.DoesNotExist:
				user = None

		if user:
			
			if int(user.otp) == int(otp):

				print("---------------------otp--vervevrvrvr----------")
				otp_send_time = user.otp_send_time
				otp_send_time = otp_send_time.astimezone (tz) + timedelta (hours=1)

				otp_date = datetime.strftime (otp_send_time, '%m/%d/%y')
				otp_time = datetime.strftime (otp_send_time, '%H:%M')


				if now_date == otp_date and now_time <= otp_time:
					user.otp_varification = True
					user.profile_status = 2
					user.save()
					AlarmModel.objects.create(user = user)
					return {"data": {"user":user.encoded_id}, "code": status.HTTP_200_OK, "message": OTP_VERIFID}
				else:
					return {"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": OTP_EXPIRED}
			else:
				return ({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":WRONG_OTP})
		else:
			return {"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": DETAILS_INCORRECT}

	def logout(self, request, format=None):

		validated_data = self.validate_logout_data(request)
		try:
			jwt_token_str = request.META['HTTP_AUTHORIZATION'] 
			jwt_token = jwt_token_str.replace('Bearer', '')
			user_detail = jwt.decode(jwt_token, None, None)
			user = User.objects.get(pk=user_detail['user_id'])

			user_session_instance = self.get_user_session_object(user.pk, request.headers.get('device-type'), request.data.get('device_id'))

			if user_session_instance:
				user_session = self.create_update_user_session(user, None, request)
				return ({"data": None, "code": status.HTTP_200_OK, "message": "LOGOUT_SUCCESSFULLY"})
			else:
				return ({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"RECORD_NOT_FOUND"})

		except User.DoesNotExist:
			return ({"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": "RECORD_NOT_FOUND"})

	def set_password(self, request, format=None):
		try: 
			user = User.objects.get(encoded_id = request.data["encoded_id"])
			user.set_password(request.data["password"])
			user.profile_status = 3
			user.save()
			self.generate_encoded_id(user)
			return({"data":{"user":user.encoded_id}, "code":status.HTTP_200_OK, "message":"Password set successfully !"})
		except User.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"You Entered wrong encoded id"})

	
	def add_user_details(self, request, format=None):
		"""
		Add user details
		"""
		try:
			user = User.objects.get(encoded_id = request.data["encoded_id"])
			request.data['role'] = 2
			request.data['profile_status'] = 3
			if user.is_social == True:
				if user.social_type == 1:
					try:
						user_obj = User.objects.get(email=request.data['email'])
					except User.DoesNotExist:
						user_obj = None
					if user_obj is not None:
						return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":EMAIL_ALREADY_EXIST}) 
				# else:
				# 	user_obj = User.objects.filter(email=request.data['email'])
					
				# 	if len(user_obj) > 1:
				# 		return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":EMAIL_ALREADY_EXIST}) 



				try:
					user_obj = User.objects.get(phone_no=request.data['phone_no'])
				except User.DoesNotExist:
					user_obj = None
				if user_obj is not None:
					return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":PHONE_ALREADY_EXIST}) 


			if 'email' in request.data:
				try:
					user_obj = User.objects.get(email=request.data['email'])
				except User.DoesNotExist:
					user_obj = None
				if user_obj is not None:
					return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":EMAIL_ALREADY_EXIST}) 
			if 'phone_no' in request.data:
				try:
					user_obj = User.objects.get(phone_no=request.data['phone_no'])
				except User.DoesNotExist:
					user_obj = None
				if user_obj is not None:
					return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":PHONE_ALREADY_EXIST}) 

			serializer = UserCreateUpdateSerializer(user, data=request.data)

			if serializer.is_valid():
				serializer.save()
				return({"data":None, "code":status.HTTP_200_OK, "message":"User Details Added successfully"})
			return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		except User.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"You Entered wrong encoded id"})

	def add_user_vitals(self, request, format=None):
		"""
		Add User Vitals
		"""
		try:
			user = User.objects.get(encoded_id = request.data["encoded_id"])
			request.data['role'] = 2
			serializer = UserCreateUpdateSerializer(user, data=request.data)

			if serializer.is_valid():
				serializer.save()
				user.encoded_id = None
				user.profile_status = 4
				user.save()
				login(request, user)
				serializer = UserLoginDetailSerializer(user)
				payload = jwt_payload_handler(user)
				token = jwt.encode(payload, settings.SECRET_KEY)
				user_details = serializer.data
				if user.profile_status == 4:
					user_details['token'] = token
					user_session = self.create_update_user_session(user, token, request)
				return({"data":user_details, "code":status.HTTP_200_OK, "message":"User Details Added successfully"})
			return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
		except User.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"You Entered wrong encoded id"})

	def get_user_vitals(self, request, format=None):
		user_obj = User.objects.get(id=request.user.id)
		serializer = UserVitalsSerializer(user_obj)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":VITALS_FETCHED})

	def set_user_vitals(self, request, format=None):
		user_obj = User.objects.get(id=request.user.id)
		serializer = UserVitalsSerializer(user_obj, data=request.data)
		if serializer.is_valid():
			serializer.save()
			return({"data":serializer.data, "code":status.HTTP_200_OK, "message":VITALS_UPDATED})
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})

	def get_user_profile(self, request, format=None):

		"""
		Get User Profile by Token
		"""
		
		user_id = get_user_by_token(request)['user_id']
		# try:
		# 	print("---------------------------helo---------------------",user_id)
		# 	NotificationModel.objects.filter(user = user_id, is_read=False).delete()
		# except :
		# 	pass
		print('-------------------------------')
		user_obj= User.objects.get(id=user_id)
		serializer = UserGetSerializer(user_obj)
		data2 = serializer.data
		sub_data = {
								"sub_id":user_obj.sub_id,
								"sub_start_date":user_obj.sub_start_date,
								"sub_end_date":user_obj.sub_end_date,
								"sub_price":user_obj.sub_price,
								"sub_is_ads":user_obj.sub_is_ads
								}
		data2["sub_details"]=sub_data
		data2["is_active_lazybone"] = user_obj.is_active_lazybone
		return({"data":data2, "code":status.HTTP_200_OK, "message":OK})

	# def update_user_profile(self, request, format=None):
	# 	"""
	# 	Update User Profile By Token
	# 	"""

	# 	if 'fitbit_id' in request.data:
	# 		user_obj = User.objects.filter(fitbit_id = request.data['fitbit_id']).exclude(id = request.user.id).update(fitbit_id = None)
	# 		# if user_obj.count() > 0:
				
				
	# 			# return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"User with this fitbit id already exists."})

	# 	user_id = get_user_by_token(request)['user_id']
	# 	user_obj= User.objects.get(id=user_id)
	# 	serializer = UserCreateUpdateSerializer(user_obj, data=request.data)
	# 	if serializer.is_valid():
	# 		serializer.save()
	# 		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
	# 	else:
	# 		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})

	def update_user_profile(self, request, format=None):
		"""
		Update User Profile By Token
		"""

		if 'fitbit_id' in request.data:
			user_obj = User.objects.filter(fitbit_id = request.data['fitbit_id']).exclude(id = request.user.id).update(fitbit_id = None)
			# if user_obj.count() > 0:
				
				
				# return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"User with this fitbit id already exists."})

		user_id = get_user_by_token(request)['user_id']
		user_obj= User.objects.get(id=user_id)
		if "sub_details" in request.data:
			sub_data = request.data["sub_details"]
			if "sub_id" in sub_data and "sub_price" in sub_data and "no_of_days" in sub_data:

				serializer = UserCreateUpdateSerializer(user_obj, data=request.data)
				if serializer.is_valid():
					serializer.save()

					user = User.objects.get(id=serializer.data.get("id"))
					user.sub_id = sub_data["sub_id"]
					date = datetime.now()
					user.sub_start_date = date
					user.sub_end_date = date + timedelta(days=sub_data["no_of_days"])
					user.sub_price = sub_data["sub_price"]
					if "sub_is_ads" in sub_data:
						user.sub_is_ads = sub_data["sub_is_ads"]
					user.save()

					serializer = UserCreateUpdateSerializer(user)
					data2 = serializer.data
					sub_data = {
								"sub_id":user.sub_id,
								"sub_start_date":user.sub_start_date,
								"sub_end_date":user.sub_end_date,
								"sub_price":user.sub_price,
								"sub_is_ads":user.sub_is_ads
								}
					data2["sub_details"]=sub_data
					return({"data":data2, "code":status.HTTP_200_OK, "message":OK})
				else:
					return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":"BAD REQUEST"})

			else:
				return({"data":"error", "code":status.HTTP_400_BAD_REQUEST, "message":"Please fill all fields"})


		else:
			serializer = UserCreateUpdateSerializer(user_obj, data=request.data)
			if serializer.is_valid():
				serializer.save()

				return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
			else:
				return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":"BAD REQUEST"})


	def create_branches(self, request, format=None):
		"""
		create branches
		"""
		serializer = CreateBranchesSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return({"data":None, "code":status.HTTP_201_CREATED, "message":"Branch Created SuccessFully !"})
		#if not valid
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
	
	def create_classes(self, request, format=None):
		"""
		create Classes
		"""
		serializer = CreateClassesSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return({"data":None, "code":status.HTTP_201_CREATED, "message":"Class Created SuccessFully !"})
		#if not valid
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})
	
	def create_sections(self, request, format=None):
		"""
		create Sections
		"""
		serializer = CreateClassSectionSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return({"data":None, "code":status.HTTP_201_CREATED, "message":"Class Section Created SuccessFully !"})
		#if not valid
		return({"data":serializer.errors, "code":status.HTTP_400_BAD_REQUEST, "message":BAD_REQUEST})


	def get_all_branches(self, request, format=None):
		"""
		get all branches
		"""
		branch_objs = Branch.objects.all()
		serializer = GetBranchesSerializer(branch_objs, many=True)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})

		
	
	def get_all_classes_by_branch_id(self, request, branch_id, format=None):
		"""
		get all Classes
		"""
		class_objs = Classes.objects.filter(branch = branch_id)
		serializer = GetClassesSerializer(class_objs, many=True)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
	
	def get_all_sections_by_class_id(self, request, class_id, format=None):
		"""
		get all Sections
		"""
		sections_objs = ClassSection.objects.filter(section_class = class_id)
		serializer = GetClassSectionSerializer(sections_objs, many=True)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
	
	def forgot_password(self, request, format=None):
		"""
		This method is for Forgot password.
		"""
		if "email" in request.data:
			
			try:
				tz = pytz.timezone ('Asia/Kolkata')
				current_time = datetime.now (tz)
				user = User.objects.get(email=request.data.get("email"))
				otp = random.randint (1000, 9999)
				user.otp = otp
				# user.otp_varification = False
				user.otp_send_time = current_time
				user.save ()
				context = {"otp":otp}
				body_msg = render_to_string ('api/email/forgot-password-email.html', context)
				msg = EmailMultiAlternatives ("Email Varification<Don't Reply>", body_msg, "sagarseth@apptunix.com", [user.email])
				msg.content_subtype = "html"  
				msg.send()
				return({"data":None, "code":status.HTTP_200_OK, "message": OTP_SENT})
			except Exception as e:
				return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})
		else:
			try:
				user = User.objects.get(country_code=request.data.get("country_code"),phone_no=request.data.get("phone_no"))
				res = self.send_twillio_message(user)
				if res == False:
						return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":"Please enter a valid phone number!"})	
				return({"data":None, "code":status.HTTP_200_OK, "message": OTP_SENT})
			except User.DoesNotExist:
				return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def forgot_verify_otp(self, request, format=None):
		tz = pytz.timezone ('Asia/Kolkata')
		current_time = datetime.now (tz)
		now_date = current_time.strftime ('%m/%d/%y')
		now_time = current_time.strftime ('%H:%M')

		otp = request.data['otp']
		user = None
		if "email" in request.data and len(request.data["email"]) != 0:
			try:
				user = User.objects.get(email=request.data["email"])
			except User.DoesNotExist:
				user = None
		else:
			try:
				user = User.objects.get(phone_no=request.data["phone_no"], country_code = request.data["country_code"])
			except User.DoesNotExist:
				user = None

		if user:
			if int(user.otp) == int(otp):
				otp_send_time = user.otp_send_time
				otp_send_time = otp_send_time.astimezone (tz) + timedelta (minutes=10)

				otp_date = datetime.strftime (otp_send_time, '%m/%d/%y')
				otp_time = datetime.strftime (otp_send_time, '%H:%M')

				if now_date == otp_date and now_time <= otp_time:
					user.otp_varification = True
					user.save()
					return {"data": None, "code": status.HTTP_200_OK, "message": OTP_VERIFID}
				else:
					return {"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": OTP_EXPIRED}
			else:
				return ({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":WRONG_OTP})
		else:
			return {"data": None, "code": status.HTTP_400_BAD_REQUEST, "message": DETAILS_INCORRECT}


	def change_password(self, request, format=None):
		if "email" in request.data and len(request.data["email"]) != 0:
			try:
				user = User.objects.get(email=request.data["email"])
			except User.DoesNotExist:
				user = None
		else:
			try:
				user = User.objects.get(phone_no=request.data["phone_no"], country_code = request.data["country_code"])
			except User.DoesNotExist:
				user = None
		
		if user:
			user.set_password(request.data["password"])
			user.save()
			return({"data":None, "code":status.HTTP_200_OK, "message":"Password updated successfully !"})
		else:
			return({"data":None, "code":status.HTTP_204_NO_CONTENT, "message":RECORD_NOT_FOUND})
	
	def get_user_details_by_token(self, request, format=None):
		try:
			user_details = get_user_by_token(request)
			details_obj =  User.objects.get(pk=user_details["user_id"])
			serializer= UserDetialsSerializer(details_obj)
			return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})
		except User.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message":RECORD_NOT_FOUND})
	
	def updatePassword(self, request, format=None):
		user_details = get_user_by_token(request)
		try:
			user = User.objects.get(id=user_details["user_id"])
		except User.DoesNotExist:
			user = None
		if user is not None:
			user.set_password(request.data.get("new_password"))
			user.save()
			return({"data":None, "code":status.HTTP_200_OK, "message": PASSWORD_CHANGE_SUCCESSFULLY})
		
		else:
			return({"data":None, "code":status.HTTP_400_BAD_REQUEST, "message": RECORD_NOT_FOUND})

	def update_profile_detials(self, request, user_id , format=None):
		"""
		Updates detail
		"""
		data = request.data
		user_details = get_user_by_token(request)
		user = User.objects.get(id=user_id)
		serializer = UserUpdateDetialsSerializer(user, data=data)
		if serializer.is_valid ():
			serializer.save ()
			return ({"data": serializer.data, "code": status.HTTP_200_OK,"message":USER_DETAIL_UPDATED})
		else:
			return ({"data": serializer.errors, "code": status.HTTP_400_BAD_REQUEST,"message":BAD_REQUEST})

	def get_all_teahcer_class_details(self, request, format=None):
		"""
		get all teacher classes details.
		"""
		user_id = get_user_by_token(request)["user_id"]
		user_class = UserClassDetails.objects.filter(user=user_id)
		serializer = GetUserClassDetailsSerializer(user_class, many=True)
		return({"data":serializer.data, "code":status.HTTP_200_OK, "message":OK})

	def get_dashboard_count(self,request,format=None):
		data = {}
		data['total_users'] = User.objects.filter(role_id=2, is_deleted=False, profile_status=4).filter(is_active=True).count()
		data['total_emergency_messages']=0
		return({"data":data, "code":status.HTTP_200_OK, "message":OK})

	def get_emergency_contacts(self, request, format=None):
		print(request.user.id)
		user_obj = User.objects.get(id=request.user.id)
		contacts_obj = EmergencyContacts.objects.filter(user = request.user.id)
		serializer = GetUpdateEmergencyContactsSerializer(contacts_obj, many=True)
		data = {}
		data['contacts'] = serializer.data
		data['emergency_message'] = user_obj.emergency_message
		return({"data":data, "code":status.HTTP_200_OK, "message":EMERGENCY_CONTACTS_FETCHED})


	def update_emergency_contacts(self, request, format=None):
		contacts_obj = EmergencyContacts.objects.filter(user = request.user.id)
		user_obj = User.objects.get(id=request.user.id)
		if 'emergency_message' not in request.data:
			user_obj.emergency_message = 'Your friend, is in Emregency, Please Respond.!!'
			user_obj.save()
		else:
			user_obj.emergency_message = request.data['emergency_message']

			user_obj.save()
		for obj in contacts_obj:
			obj.delete()
		
		for emergency_obj in request.data['contacts']:
			contacts = EmergencyContacts.objects.create(user = user_obj, **emergency_obj)
		return({"data":None, "code":status.HTTP_200_OK, "message":EMERGENCY_CONTACTS_UPDATED})


	def get_vital_status(self, request, format=None):
		print("fusgdfuwgefusfugswufgwsufgsufgu8gfufgu8fgu8sfu4444444444$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$-----------------------------------------")
		print(request.data)
		user_obj = User.objects.get(id=request.user.id)
		expected_min_heart_rate = user_obj.min_heart_rate
		expected_expected_max_heart_rate = user_obj.max_heart_rate
		expected_min_spo2 = user_obj.min_spo2
		expected_max_spo2 = user_obj.max_spo2
		expected_min_heart_rate_variability = user_obj.min_heart_rate_variability
		expected_max_heart_rate_variability = user_obj.max_heart_rate_variability

		actual_heart_rate = request.data['heart_rate']
		try:
			actual_spo2 = request.data['spo2']
			actual_heart_rate_variability = request.data['heart_rate_variability']
		except:
			None
		data = {"health_status":False}
		issues = []
		if float(actual_heart_rate) < float(expected_min_heart_rate):
			issues.append("User's Heart Rate is Critically Low.")
		if float(actual_heart_rate) > float(expected_expected_max_heart_rate):
			issues.append("User's Heart Rate is Critically High.")

		try:
			if float(actual_spo2) < float(expected_min_spo2):
				issues.append("User's Oxygen Levels are Critically Low.")
			if float(actual_spo2) > float(expected_max_spo2):
				issues.append("User's Oxygen Levels are Critically High.")
			if float(actual_heart_rate_variability) < float(expected_min_heart_rate_variability):
				issues.append("User's Heart Rate Variability is Critically Low.")
			if float(actual_heart_rate_variability) > float(expected_max_heart_rate_variability):
				issues.append("User's Heart Rate Variability is Critically High.")
		except:
			None

		if issues == []:
			return({"data":None, "code":status.HTTP_200_OK, "message":OK})
		else:
			tz = pytz.timezone ('Asia/Kolkata')
			current = datetime.now(tz)
			time = current.strftime('%H:%M')
			alarm_data = {
				"user": request.user,
				"last_alarm_time":time,
				"is_snooze":False,
				"alarm_reason":issues[0] + "  Please click to close alert alarm",
				"isLocl":True
			}
			try:
				alarm = AlarmModel.objects.get(user=request.user.id)
				alarm.last_alarm_time = time
				alarm.isLocl = True
				alarm.alarm_reason = issues[0] + "  Please click to close alert alarm"
				alarm.save()

				# if alarm.count() > 0:
				# 	alarm_data['is_snooze'] = alarm[0].is_snooze
				# 	alarm.delete()
			except:
				print("in excccccccccc")
				alarm = AlarmModel.objects.create(**alarm_data)
				print("in alarm", alarm)

			subject = "reminder-notification"
			notification_type = "reminder-notification"
			msg = issues[0] + "  Please click to close alert alarm"
			# extra_args = {"alarm":alarm.id}
			print("----------&&&&&&&&&&&&&&&&&&&&&&&&&-----------get vital ",request.user.id)

			
			noti_obj = NotificationModel.objects.filter(user = request.user.id).latest('sent_date')
			print('----------------------------------------------------Apple watch->>>')
			
			UTC = pytz.utc
			print(datetime.now(UTC))

			x = datetime.now(UTC) - noti_obj.sent_date
			print((x.total_seconds()))
			print('----------------------------------------------------Apple watch->>>')
			try:
				alarm_obj = AlarmModel.objects.filter(user = request.user.id)[0]
				a_val = alarm_obj.is_snooze
			except :
				alarm_obj = None
				a_val = False

			
			print("--------------alalalalalalalala",int(x.total_seconds()),a_val)
			if (int(x.total_seconds()) >= 15 and a_val is False):
				print('------------------>> notification hit____>>>>1111111111111111111111>>>>>>>>>>')
				print(int(x.total_seconds()))
				if int(x.total_seconds()) < 20 :
					print("------<><><>><><><><><><><><><>><<><<>> in less 5353535353535335353535353553")
			
					print("------<><><>><><><><><><><><><>><<><<>> in less 5353535353535335353535353553")
					print(alarm_obj.consecutive_notification_count)
					alarm_obj.consecutive_notification_count = alarm_obj.consecutive_notification_count + 1

					alarm_obj.save()
				else:
					print("------<><><>><><><><><><><><><>><<><<>> in LARGELARLARLALRLALRLALR 5353535353535335353535353553")

					alarm_obj.consecutive_notification_count = 0
					alarm_obj.save()

				alarm_obj.save()
				print(" send send s ese  s s s s  s   s    s    s  s   s    s    s    s     s    s    s")
				if alarm_obj.consecutive_notification_count == 1:
					volume = 5
					critical=0
					alarm_obj.isLocl = True
					alarm_obj.save()
				elif alarm_obj.consecutive_notification_count == 2:
					volume = 5
					critical=1
					if alarm_obj.isLocl  == True:
						alarm_obj.isLocl = False
						alarm_obj.save()
				elif alarm_obj.consecutive_notification_count > 2:
					volume = 10
					critical=1
					if alarm_obj.isLocl  == True:
						alarm_obj.isLocl = False
						alarm_obj.save()
				else :
					volume = 3
					critical=0
					alarm_obj.isLocl = True
					alarm_obj.save()

				print(alarm.user, subject, msg,volume,critical,alarm_obj.isLocl, notification_type,'=====testttttttttt')
				notification_message.send_push_notification(alarm.user, subject, msg,volume,critical,alarm_obj.isLocl, notification_type)
				# if alarm_obj.consecutive_notification_count == 1 or alarm_obj.consecutive_notification_count == 2 or alarm_obj.consecutive_notification_count == 3:
				print("i am in sed msg block block block ")

				try :
					print(alarm_obj.consecutive_notification_count !=0 and alarm_obj.consecutive_notification_count < 9,'====tttttttttttt')
					if alarm_obj.consecutive_notification_count !=0 and alarm_obj.consecutive_notification_count < 9 :
						print(alarm_obj.consecutive_notification_count,'====ccccccccvount')
						if alarm_obj.consecutive_notification_count % 2 == 0 :



							from api.utils.sendEmergencyMessage import send_twillio_emergency_message
							emergency_obj = EmergencyContacts.objects.filter(user = request.user.id)
							print("ememeregenecy cocnctctctufufu++++++++++++++++++++++++++++++++++++ startess hehrhwehrhherhehrh")
							print(emergency_obj)
							try:
								print(emergency_obj.values_list("id"))
							except:
								print("exexexexexexexexexex")
							for emrgency in emergency_obj:
								if emrgency.contact_number[:3] == '+91':
									send_number = emrgency.contact_number
									print("----------11111111111-------send send send sne d sndsndnsndsdsdsd  msg msg smsg ",alarm_obj.consecutive_notification_count)
									print(send_number)
									print('nooooooooooooooooooooooooo')
									send_twillio_emergency_message(send_number,request.user)

								else:
									send_number = '+1' + emrgency.contact_number
									print("-----------------send send send sne d sndsndnsndsdsdsd  msg msg smsg ",alarm_obj.consecutive_notification_count)
									print(send_number)
									print('nooooooooooooooooooooooooo')
								ans=send_twillio_emergency_message(send_number,request.user)
								print(ans,'===================================anssssssssssss')
				except :
						pass


			try:
				print(request.header)
			except:
				None
			try:
				print(request.headers)
			except:
				None
			return ({"data": issues, "code": status.HTTP_200_OK,"message":HEALTH_ISSUE_DETECTED})
		

	def send_twillio_message(self, user):
		try:
			otp = random.randint (1000, 9999)
			body_msg = 'Your OTP is {} . OTP is valid for 1 hour or 1 successfull attempt.'.format (
					otp)

			account_sid = "ACe91aa98e6d1f900dbd49eb869187d1bd"
			auth_token = "376b2cb67c5fe4e01392de42bd2e0e7d"
			# print("{}{}".format(user.country_code, user.phone_no))
			client = Client(account_sid, auth_token)
			to = "{}{}".format(user.country_code, user.phone_no)
			# to = "+918146664616"

			print("--------------<><><><><><><><---------------------------")
			print(to)
			message = client.messages.create(
					to=to,
					from_="+18456134780",
					body=body_msg)
			print("---------------send it ---------------------")
			tz = pytz.timezone ('Asia/Kolkata')
			current_time = datetime.now (tz)

			user.otp = otp
			user.otp_send_time = current_time
			user.save ()
			return otp
		except:
			return False



		


	def update_snooze_status(self, request, format=None):

		print("-----------------------------------snooze snooze ",request.data, request.user, request.user.id)

		tz = pytz.timezone('Asia/Kolkata')
		current = datetime.now(tz)
		time = current.strftime('%H:%M:%S')
		try:
			sn_status = request.data.get('is_snooze')
			if sn_status is None:
				sn_status = False
			# alarm = AlarmModel.objects.filter(user=request.user.id).update(is_active=sn_status, is_snooze=sn_status)
			
			alarm = AlarmModel.objects.get(user=request.user.id)
			noti_obj = NotificationModel.objects.filter(user = request.user.id).latest('sent_date')
			if sn_status is None or sn_status is False :
				if alarm.consecutive_notification_count > 1:
					alarm.consecutive_notification_count = 0
					# noti_obj.sent_date=noti_obj.sent_date + timedelta(seconds=21)
					alarm.save()

			emergency_obj = EmergencyContacts.objects.filter(user = request.user.id)
			print(time,' == ', current.strftime('%H:%M:%S'))

			def emergency_msg(time, type=None):

				for emrgency in emergency_obj:
					if emrgency.contact_number[:3] == '+91':
						send_number = emrgency.contact_number
					else:
						send_number = '+1' + emrgency.contact_number
					print('msggggggggggggggggggggggggg', send_number)
					send_twillio_emergency_message(send_number,request.user, type=type)

			if sn_status == True:
				if request.data.get("is_msg"):
					emergency_msg(time, 2)
				alarm.last_alarm_time = time
				alarm.is_snooze=sn_status
				alarm.is_active=True
				alarm.save()
				return({"data":None, "code":status.HTTP_200_OK, "message":"Alarm snoozed successfully!"})
			else:

				alarm.last_alarm_time = time
				alarm.is_snooze=sn_status
				alarm.is_active=False
				alarm.save()
				return({"data":None, "code":status.HTTP_200_OK, "message":"Alarm closed successfully!"})
		except AlarmModel.DoesNotExist:
			return({"data":None, "code":status.HTTP_400_BAD_REQEST, "message":RECORD_NOT_FOUND})




"""

if (int(x.total_seconds()) >= 30 and a_val is False) or (x.total_seconds() < 0 ):
				print('------------------>> notification hit____>>>>1111111111111111111111>>>>>>>>>>')
				print(int(x.total_seconds()))
				if int(x.total_seconds()) < (36) and (x.total_seconds() > 0 ) :
					print("------<><><>><><><><><><><><><>><<><<>> in less 5353535353535335353535353553")
"""

"""

if int(x.total_seconds()) >= 30 and a_val is False:
				print('------------------>> notification hit____>>>>1111111111111111111111>>>>>>>>>>')
				print(int(x.total_seconds()))
				if int(x.total_seconds()) < (36):
"""