from django.urls import path
from .views import *

app_name = 'api'

urlpatterns = [
    path('auth/login/', LoginView.as_view(), name='login'),
    path('auth/admin/login/', AdminLoginView.as_view(), name='admin-login'),
    path('auth/logout/', LogoutView.as_view(), name='logout'),
    path('auth/sign-up/', SignupView.as_view(), name='auth-sign-up'),
    path('auth/touchid/login/', TouchIDLoginView.as_view(), name='touchid-login'),
    
    #OTP
    path('user/verify-otp/', VarifyOtpView.as_view(), name="verify-otp"),
    path('user/send-otp-to-old-user/', SendOtpForOldUser.as_view(), name="send-otp-to-old-user"),
    path('user/set-password/', SetUserPasswordView.as_view(), name="set-password"),
    path('user/add-user-details/', AddUserDetialsView.as_view(), name="add-user-details"),
    path('user/add-user-vitals/', AddUserVitalsView.as_view(), name="add-user-vitals"),
    
    path('user/get-user-profile-by-token/', GetUserProfileView.as_view(), name="get-user-profile-by-token"),
    path('user/update-user-profile-by-token/', GetUserProfileView.as_view(), name="update-user-profile-by-token"),


    path('user/get-emergency-contacts-by-token/', GetUpdateEmergencyContactsView.as_view(), name="get-emergency-contacts-by-token"),
    path('user/update-emergency-contacts-by-token/', GetUpdateEmergencyContactsView.as_view(), name="update-emergency-contacts-by-token"),
    path('user/get-vitals-status/', GetVitalStatusView.as_view(), name="update-emergency-contacts-by-token"),
    path('user/update-snooze-status/', UpdateSnoozeStatusView.as_view(), name="update-snooze-status"),
    
    #Forgot-password
    path('user/forgot-password/',ForgotPasswordView.as_view(), name="forgot-password"),
    path('user/forgot-verify-otp/',ForgotVerifyOtpView.as_view(), name="forgot-password-verify-otp"),
    path('user/update-password/', ChangePasswordView.as_view(), name="change-password"),
    path('user/change-password/',UpdatePasswordView.as_view(), name="update-password"),

    #Profile
    path('user/get-user-details-by-token/',GetUserDetialsByTokenView.as_view(), name="get-user-details-by-token"),
    path('user/update-user-details/<int:user_id>/',UpdateUsersDetailsView.as_view(), name="update-user-details"),
    path('user/get-vitals-by-token/',UserVitalsView.as_view(), name="get-vitals-by-token"),
    path('user/set-vitals-by-token/',UserVitalsView.as_view(), name="set-vitals-by-token"),
    # path('user/get-all-teacher-classes-by-token/',GetAllTeacherClassDetails.as_view(), name="update-user-details"),

    

    # #organisation
    # path('branch/create-branch/', CreateGetBranchView.as_view(), name="create-branch"),
    # path('branch/get-all-branches/', CreateGetBranchView.as_view(), name="get-all-branches"),
    # path('class/create-classes/', CreateGetClassesView.as_view(), name="create-classes"),
    # path('class/get-all-classes-by-branch-id/<int:branch_id>/', CreateGetClassesView.as_view(), name="get-all-classes-by-branch-id"),
    # path('class/create-sections/', CreateGetSectionsView.as_view(), name="create-sections"),
    # path('class/get-all-sections-by-class-id/<int:class_id>/', CreateGetSectionsView.as_view(), name="get-all-sections-by-class-id"),
    
    #role
    path('role/get-all-roles/', RoleListView.as_view(), name="get-all-role"),
    path('role/create-role/', RoleCreateView.as_view(), name="create-role"),

    #education-history
    path("education-history/create", CreateEducationView.as_view(), name="create-education-history"),
    
    #uploadMedia
    path('upload/media/', UploadMediaView.as_view(), name="upload-media"),
    path('delete-media/<int:pk>/', DeleteMediaView.as_view(), name="delete-media"),

    #CMS
    path("cms/create-update-cms/",CreateUpdateCmsView.as_view(),name="create-cms"),
    path("cms/get-cms/",GetCmsView.as_view(),name="get-cms"),
    path("cms/get-create-update-delete-faq/",CreateUpdateFaqView.as_view(),name="create-update-delete-faq"),
    path("cms/get-faq/",GetFaqView.as_view(),name="get-faq"),

    #dashboard
    path("dashboard/get-dashboard-details/",GetDashboardDetialsView.as_view(),name="get-dashboard-details"),


    #admin

    path("admin/get-all-users-with-pagination/", AdminGetAllUsersView.as_view(), name="get-all-users-with-pagination"),
    path("admin/get-all-users-without-pagination/", AdminGetUserWithoutPaginationView.as_view(), name="get-all-users-without-pagination"),
    path("admin/get-user-details-by-id/<int:user_id>/", AdminGetAllUsersView.as_view(), name="get-all-users-with-pagination"),
    # path("admin/get-user-details-by-id/<int:user_id>/", AdminGetAllUsersView.as_view(), name="get-all-users-with-pagination"),
    path("admin/add-user/", AddUserView.as_view(), name="get-all-users-with-pagination"),
    path("admin/delete-users-by-id/<int:user_id>/", AdminGetAllUsersView.as_view(), name="get-all-users-with-pagination"),
    path("admin/update-user-details-by-id/<int:user_id>/", AdminGetAllUsersView.as_view(), name="get-all-users-with-pagination"),
    path("admin/change-user-status-by-id/<int:user_id>/", ChangeUserStatusView.as_view(), name="get-all-users-with-pagination"),

    path("admin/get-total-users-graph/", GetTotalUsersGraphView.as_view(), name="get-total-users-graph"),
    path("admin/get-total-emergency-messages-graph/", GetTotalEmegencyMessageGraphView.as_view(), name="get-total-emergency-messages-graph"),

    path("admin/create-notifications/", AdminNotificationsView.as_view(), name="create-notifications"),
    path("admin/get-all-notifications/<str:notification_type>/",GetAdminNotificationsView .as_view(), name="get-all-notifications"),
    path("admin/get-user-list/",GetUsersView.as_view(), name="get-user-list"),

    path("admin/add-emergency-actions/",EmergencyActionsView.as_view(), name="get-user-list"),
    path("admin/get-emergency-actions/",EmergencyActionsView.as_view(), name="get-user-list"),
    # path("admin/update-emergency-actions/",EmergencyActionsView.as_view(), name="get-user-list"),
    # path("admin/delete-emergency-actions/",EmergencyActionsView.as_view(), name="get-user-list"),
     
    path("admin/add-emergency-protocol/",EmergencyProtocolView.as_view(), name="get-user-list"),
    path("admin/get-emergency-protocol/",EmergencyProtocolView.as_view(), name="get-user-list"),
    path("admin/update-emergency-protocol/<int:pk>/",EmergencyProtocolView.as_view(), name="get-user-list"),
    path("admin/delete-emergency-protocol/<int:pk>/",EmergencyProtocolView.as_view(), name="get-user-list"),
    path("get-heart-rate/fetch-heart-rate-data/",GetHeartRateDataView.as_view(), name="get-heart-rate"),


    path("send-heart-rate/send-heart-rate-data/",SendHeartRateDataView.as_view(), name="get-heart-rate"),

    path("test/test/",TestView.as_view(), name="get-heart-rate"),

    # subscription 

    
    path("subscription/create-sub/",CreateSubView.as_view(), name="create-sub"),
    path("subscription/update-sub/<int:pk>/",UpdateSubView.as_view(), name="update-sub"),
    path("subscription/delete-sub/<int:pk>/",DeleteSubView.as_view(), name="delete-sub"),



]


