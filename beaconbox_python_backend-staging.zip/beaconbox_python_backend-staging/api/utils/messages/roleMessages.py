ROLE_CREATED = 'Role created successfully'
ROLE_UPDATED = 'Role updated successfully'
ROLE_DELETED = 'Role deleted successfully'
ROLE_NAME_ALREADY_EXIST = "Role with this name or full name is already exists."
ROLE_CANNOT_BE_DELETE = "You can't delete Master Role"