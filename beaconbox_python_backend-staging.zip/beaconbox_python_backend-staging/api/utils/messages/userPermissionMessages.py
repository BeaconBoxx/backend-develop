USER_PERMISSION_CREATED = 'Roll Permission created Successfully'
USER_PERMISSION_UPDATED = 'Roll Permission updated successfully'
User_PERMISSION_DELETED = 'User Permission deleted successfully'
USER_PERMISSION_NOT_FOUND = 'User Permission Not Found'
USER_NOT_EXIST = "User does not exist"