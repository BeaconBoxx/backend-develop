'''
Eventapp Notifications
'''
import pytz
from pytz import timezone
from datetime import date, datetime, timedelta
import ast
import json
from api.models import PushNotification as NotificationModel, UserSession
from django.conf import settings
from push_notifications.models import APNSDevice, GCMDevice
import html2text

class Notification(object):
    ''' Notification '''
    def __init__(self, message, user=None,volume=None,critical=None,lock=None,extras=None, title=None, notification_type=None):
        
        self.message = message
        self.user = user
        self.volume = volume
        self.critical = critical
        self.lock=lock
        self.extras = extras
        self.title = title
        self.notification_type = notification_type

        print("----------------------------------gggg     444     55     555     5     3 3     2    2 2 ")
        print("volume",self.volume)
        print("critical",self.critical)
        print(self.lock)
        if not self.lock:
            self.lock = True

    def send_to_user(self, user):
        '''Send To User '''
        self.user = user
        self.send()

    def send(self):
        ''' Send '''
        if not self.user:
            raise Exception('User not Found')
        
        # tz = pytz.timezone ('Asia/Kolkata')
        # current_date = datetime.now (tz)

        # tz = pytz.timezone('utc')

        # utc_now = datetime.now(tz)
        
        # utc_now = utc_now.strftime("%Y-%m-%d %H:%M:%S")
        
        # print(utc_now)

        local = pytz.timezone ("UTC")
        date = datetime.utcnow()
        date = date.strftime("%Y-%m-%d %H:%M:%S")
        naive = datetime.strptime(date, "%Y-%m-%d %H:%M:%S")
        local_dt = local.localize(naive, is_dst=None)
        current_date = local_dt.astimezone(pytz.utc)
        utc_timestamp = local_dt.astimezone(pytz.utc)

        print(utc_timestamp)

        notification = NotificationModel.objects.create(
            user=self.user, message=self.message,volume = self.volume,critical=self.critical,isLocl=self.lock, extra_args=self.extras, title=self.title, notification_type=self.notification_type, sent_date=utc_timestamp)
        self._send_message(notification)

    def _send_message(self, notification):
        try:
            # user_device_token = notification.user.user_session.filter(device_token__isnull=False).last()
            # self.send_notification_message(user_device_token, notification)
            print(notification.user.id)
            user_list = UserSession.objects.filter(user = notification.user.id, device_token__isnull=False)
            if user_list is not None or len(user_list) != 0:
                user_list = user_list.latest("created_at")
            print(">>>>>>>>>>>>>")
            print(user_list)
            user_device_token = user_list
            # for user_device_token in user_list:
            #     print("----5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-5-55-")
            #     print(user_device_token)

            #     self.send_notification_message(user_device_token, notification)
            
            print(">>>>>>>>>>>>>")
            print(user_list)

            self.send_notification_message(user_device_token, notification)


        except Exception as e:
            print(e)
        # try:
        #     if settings.DEBUG:
        #         user_device_token = notification.user.user_session.filter().order_by("created_at").last()
        #         self.send_notification_message(user_device_token, notification)
        #     else:
        #         send_notification_message.delay(notification.pk)
        # except ValueError:
        #     pass

    def send_notification_message(self, device, notification):
        '''send notification to device'''
        _ = self.__class__
        
        print('in send_notification_message Notification')

        print('device - ', device)

        if device and device.is_active:

            device_token = device.device_token
            device_type = device.device_type

            print('***** In send_notification_message ****')

            print('device.id - ', device.id)
            print('device_token - ', device.device_token)
            print('device_type - ', device.device_type)
            print('role - ', self.user.role.pk)

            notification_message = html2text.html2text(notification.message)

            # if ((device_type == "ANDROID" or device_type == "IOS") and device_token != None):
            #     print("checking-----------------> ")
            #     gcm_device = GCMDevice.objects.update_or_create(registration_id=device_token, cloud_message_type="FCM", user=notification.user)
            #     # sent = gcm_device[0].send_message(None, extra={"alert": "Alert","sound":"alert.caf","badge":9,  "body": notification.message, "role": self.user.role.pk, "type":notification.notification_type})

                # sent = gcm_device[0].send_message(None, extra={"title": "Alert","sound":"alert.caf",  "body": notification.message, "role": self.user.role.pk, "type":notification.notification_type, "sound":"alert.caf","volume":7.0, "critical":1})

            #     print('Android Notification Sent Status :')
            #     print(sent)

            if (device_type == "IOS" and device_token != None and device_token != ""):
                # import pdb
                # pdb.set_trace()
                # apns_device = APNSDevice.objects.update_or_create(registration_id=device_token, user=notification.user)
                

                # apns_device = APNSDevice.objects.update_or_create(registration_id=device_token, user=notification.user)
                # sent = apns_device[0].send_message(notification.message, sound="default", badge=1)

                apns_device = APNSDevice.objects.update_or_create(registration_id=device_token, user=notification.user)
                
                unread_notifications = NotificationModel.objects.filter(user = notification.user, is_read=False).count()
                unread_notifications = 0

                sent = apns_device[0].send_message(notification_message, sound = {  
         "critical": int(notification.critical),
         "name": "alert.caf",
         "volume": int(notification.volume),
         "isLocl":notification.isLocl
        }, 
        badge=unread_notifications, extra={"title": "Alert",  "body": notification.message, "role": self.user.role.pk, "type":notification.notification_type})
                print('IOS Notification Sent Status :')
                print(sent)
        

            else:
                pass

            # if sent['success'] == 1:
            #     notification.sent_status = NotificationModel.SUCCESS
            #     notification.sent_args = sent
            #     notification.save()
            # else:
            #     notification.sent_status = NotificationModel.ERROR
            #     notification.sent_args = sent
            #     notification.save()



"""
badge=unread_notifications, extra={"title": "Alert",  "body": notification.message, "role": self.user.role.pk, "type":notification.notification_type})
                print('IOS Notification Sent Status :')
                print(sent)
"""
