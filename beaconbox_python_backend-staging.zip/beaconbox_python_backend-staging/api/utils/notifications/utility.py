from api.models import User, PushNotification
from .notification import Notification as SendNotification
import json

class NotificationMessages(object):
    """
    Send Push Notifications
    """
    
    def send_push_notification(user, subject, msg, volume=None, critical=None,lock=None,notification_type=None, extra_args=None):
        if notification_type is None:
            notification_type = "Done"
        if extra_args is None:
            extra_args = json.dumps({})
        
        notification_instance = SendNotification(msg, user, volume,critical,lock,extra_args, subject, notification_type)
        notification_instance.send()