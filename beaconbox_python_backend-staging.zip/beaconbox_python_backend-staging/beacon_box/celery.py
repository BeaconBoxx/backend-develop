import os
from celery import Celery
from celery.schedules import crontab
from datetime import timedelta
# from api.task import send_alarm_and_reminder_notification
 
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'beacon_box.settings')
 
app = Celery('beacon_box')
app.config_from_object('django.conf:settings')
 
# Load task modules from all registered Django app configs.
app.autodiscover_tasks()

# app.autodiscover_tasks()
app.conf.beat_schedule = {
    "runs-every-30-seconds": {
        "task": "api.task.send_alarm_and_reminder_notification",
        "schedule": timedelta(seconds=30)
        # "args": (16, 16)
    },
}
# app.conf.beat_schedule = {
#     'send-report-every-single-minute': {
#         'task': 'api.task.send_alarm_and_reminder_notification',
#         'schedule': crontab(minute=1),  # change to `crontab(minute=0, hour=0)` if you want it to run daily at midnight
#     },
# } 



